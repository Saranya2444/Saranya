import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Timesheet from './components/Timesheet';
import EmployeeDetail from './components/EmployeeDetail';
import PersonalInformation from './components/PersonalInformation';
import styled from 'styled-components';

const Container = styled.div`
  display: flex;
`;

const PageContent = styled.div`
  flex: 1;
  padding: 20px;
  background-color: #7FC7D9;
`;

const App = () => {
  return (
    <Router>
      <Container>
        <Sidebar />
        <PageContent>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/timesheet" element={<Timesheet />} />
            <Route path="/employeedetail" element={<EmployeeDetail />} />
            <Route path="/personalinformation" element={<PersonalInformation />} />
          </Routes>
        </PageContent>
      </Container>
    </Router>
  );
};

export default App;
