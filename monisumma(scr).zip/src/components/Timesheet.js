import React, { useState } from 'react';
import './Timesheet.css';

const employees = [
  { id: 60178, name: 'John Doe', startTime: '09:00', endTime: '17:00', projectName: 'Project A', leadApproval: 'pending', managerApproval: 'pending' },
  { id: 60187, name: 'Jane Smith', startTime: '10:00', endTime: '18:00', projectName: 'Project B', leadApproval: 'rejected', managerApproval: 'rejected' },
  { id: 60189, name: 'John Smith', startTime: '10:00', endTime: '18:00', projectName: 'Project C', leadApproval: 'rejected', managerApproval: 'pending' },
  { id: 60186, name: 'Mark Antony', startTime: '10:00', endTime: '18:00', projectName: 'Project A', leadApproval: 'pending', managerApproval: 'pending' },
  { id: 60185, name: 'Ranvir Singh', startTime: '10:00', endTime: '18:00', projectName: 'Project B', leadApproval: 'approval', managerApproval: 'approval' },
];
function Timesheet() {
  const [searchTerm, setSearchTerm] = useState('');
  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };
  const filteredEmployees = employees.filter(employee =>
    employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.id.toString().includes(searchTerm)
  );
  const getStatusButton = (status) => {
    const buttonStyles = {
      pending: { backgroundColor: 'blue', color: 'white', },
      approval: { backgroundColor: 'green', color: 'white' },
      rejected: { backgroundColor: 'red', color: 'white' }
    };
    return <button style={buttonStyles[status]}>{status}</button>;
  };
  return (
    <div className="container">
    <div className="App">
      
      <input
        type="text"
        placeholder="Search by ID or Name"
        value={searchTerm}
        onChange={handleSearch}
        className="search-bar"
      />
      
      <table className="employee-table">
        <thead>
          <tr>
            <th>Emp ID</th>
            <th>Name</th>
            <th>In-Time</th>
            <th>Out-Time</th>
            <th>Project</th>
            <th>Lead Approval</th>
            <th>Manager Approval</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map(employee => (
            <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{employee.name}</td>
              <td>{employee.startTime}</td>
              <td>{employee.endTime}</td>
              <td>{employee.projectName}</td>
              <td>{getStatusButton(employee.leadApproval)}</td>
              <td>{getStatusButton(employee.managerApproval)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
  );
}
export default Timesheet;