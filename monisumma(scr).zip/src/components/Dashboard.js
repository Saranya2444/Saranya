// src/pages/Dashboard.js
import React, { useState } from 'react';
import Calendar from './Calendar';
import PopupForm from './PopupForm';
import './Dashboard.css'; // Import the CSS file

const Dashboard = () => {
  const [showPopup, setShowPopup] = useState(false);

  const handleDateClick = (date) => {
    console.log('Date clicked:', date);
    setShowPopup(true);
  };

  const closePopup = () => {
    setShowPopup(false);
  };

  return (
    <div className="dashboard">
      {showPopup && <PopupForm onClose={closePopup} />}
      <Calendar onDateClick={handleDateClick} />
    </div>
  );
};

export default Dashboard;
