// src/components/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClock, faHome, faChartBar, faTasks, faStar, faUsers, faDollarSign, faCogs } from '@fortawesome/free-solid-svg-icons';
import './sidebar.css';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="sidebar-title">
        <FontAwesomeIcon icon={faClock} />
        <span>Dashboard</span>
      </div>
      <div className="sidebar-search">
        <input type="text" placeholder="Search..." />
      </div>
      <div className="sidebar-menu">
        <Link to="/home" className="sidebar-item">
          <FontAwesomeIcon icon={faHome} />
          <span>Home Page</span>
        </Link>
        <Link to="/Timesheet" className="sidebar-item">
          <FontAwesomeIcon icon={faChartBar} />
          <span>Timesheet</span>
        </Link>
        <Link to="/Dashboard" className="sidebar-item">
          <FontAwesomeIcon icon={faStar} />
          <span>Dashboard</span>
        </Link>
        <Link to="/EmployeeDetail" className="sidebar-item">
          <FontAwesomeIcon icon={faCogs} />
          <span>Employee Detail</span>
        </Link>
        <Link to="/PersonalInformation" className="sidebar-item">
          <FontAwesomeIcon icon={faTasks} />
          <span>Personal Detail</span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
