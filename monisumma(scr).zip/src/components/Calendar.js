// src/CalendarTable.js
import React, { useState } from 'react';
import './Calendar.css';
import PopupForm from './PopupForm';

const Calendar = () => {
  const rows = Array.from({ length: 6 });
  const columns = Array.from({ length: 5 });
  const [hours, setHours] = useState(Array(30).fill([]));
  const [isPopupVisible, setPopupVisible] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [tooltip, setTooltip] = useState(null);
  const [selectedCircle, setSelectedCircle] = useState(null);

  const addHours = (index, newEntry) => {
    const updatedHours = [...hours];
    updatedHours[index] = [
      ...updatedHours[index],
      newEntry
    ];
    setHours(updatedHours);
  };

  const handleAddClick = (index) => {
    setSelectedDate(index);
    setPopupVisible(true);
  };

  const handleClosePopup = () => {
    setPopupVisible(false);
    setSelectedDate(null);
  };

  const handleAddHours = (index, newEntry) => {
    addHours(index, newEntry);
    handleClosePopup();
  };

  const handleCircleClick = (entry, index) => {
    if (selectedCircle === index) {
      setTooltip(null); // Close the tooltip if the same circle is clicked again
      setSelectedCircle(null);
    } else {
      setTooltip(entry);
      setSelectedCircle(index); // Open tooltip for the clicked circle
    }
  };

  return (
    <div className="calendar-table">
      <div className="header">
        <span>Name: John Doe</span>
        <span>Employee ID:60178</span>
        <span>Month: July</span>
        <span>Year: 2024</span>
      </div>
      
      <table>
        <tbody>
          {rows.map((_, rowIndex) => (
            <tr key={rowIndex}>
              {columns.map((_, colIndex) => {
                const index = rowIndex * 5 + colIndex;
                return (
                  <td key={colIndex}>
                    <div className="cell-content">
                      <span className="date">{index + 1}</span>
                      <br></br>
                      <button
                        className="add-hours"
                        onClick={() => handleAddClick(index)}
                      >
                     
                        +
                      </button>
                      <div className="hours-circles">
                        {hours[index].map((entry, i) => (
                          <div
                            key={i}
                            className="hours-circle"
                            style={{ backgroundColor: entry.color }}
                            onClick={() => handleCircleClick(entry, index)}
                          >
                            {entry.hours}
                          </div>
                        ))}
                      </div>
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {isPopupVisible && (
        <PopupForm
          onClose={handleClosePopup}
          onAddHours={handleAddHours}
          selectedDate={selectedDate}
        />
      )}
      {tooltip && (
        <div className="tooltip" style={{ top: '50px', left: '50px' }}>
          <p><strong>Project Name:</strong> {tooltip.projectName}</p>
          <p><strong>Start Time:</strong> {tooltip.startTime}</p>
          <p><strong>End Time:</strong> {tooltip.endTime}</p>
          <p><strong>Hours:</strong> {tooltip.hours}</p>
          <p><strong>Comments:</strong> {tooltip.comments}</p>
         
        </div>
      )}
    </div>
  );
};

export default Calendar;
