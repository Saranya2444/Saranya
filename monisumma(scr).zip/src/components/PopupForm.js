// src/popupform.js
import React, { useState } from 'react';
import styled from 'styled-components';

const Overlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
 
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
`;

const FormContainer = styled.div`
  background-color:#0F1035;
  padding: 20px;
  border-radius: 10px;
  width: 300px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
`;

const InputField = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  color: #538392;
`;

const Input = styled.input`
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
`;

const TextArea = styled.textarea`
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
`;

const Button = styled.button`
  background-color: #0F1035;
  color: white;
  padding: 10px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin-right: 10px;

  &:hover {
    background-color: #80B9AD;
  }
`;

const CancelButton = styled(Button)`
  background-color:black;
  color:white;

  &:hover {
    background-color: #999;
  }
`;

const ColorPicker = styled.div`
  display: flex;
  gap: 10px;
`;

const ColorOption = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 50%;
  cursor: pointer;
  border: 1px solid #000;
`;

const PopupForm = ({ onClose, onAddHours, selectedDate }) => {
  const [projectName, setProjectName] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [hours, setHours] = useState('');
  const [comments, setComments] = useState('');
  const [color, setColor] = useState('#ff0000'); // Default color red

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!projectName || !startTime || !endTime || !hours) {
      alert('Please fill in all required fields.');
      return;
    }
    // Handle form submission logic here
    onAddHours(selectedDate, { hours: parseInt(hours, 10), color });
    onClose();
  };

  const handleCancel = () => {
    onClose();
  };

  return (
    <Overlay>
      <FormContainer>
        <form onSubmit={handleSubmit}>
          <InputField>
            <Label><b>Project Name</b></Label>
            <Input
              type="text"
              aria-label="Project Name"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
            />
          </InputField>
          <InputField>
            <Label><b>Start Time</b></Label>
            <Input
              type="time"
              aria-label="Start Time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
            />
          </InputField>
          <InputField>
            <Label><b>End Time</b></Label>
            <Input
              type="time"
              aria-label="End Time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
            />
          </InputField>
          <InputField>
            <Label><b>Number of Hours</b></Label>
            <Input
              type="number"
              aria-label="Number of Hours"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
            />
          </InputField>
          <InputField>
            <Label><b>Comments</b></Label>
            <TextArea
              aria-label="Comments"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
            />
          </InputField>
          <InputField>
            <Label><b>Select Color</b></Label>
            <ColorPicker>
              <ColorOption
                style={{ backgroundColor: '#ff0000' }}
                onClick={() => setColor('#ff0000')}
              />
              <ColorOption
                style={{ backgroundColor: '#00ff00' }}
                onClick={() => setColor('#00ff00')}
              />
              <ColorOption
                style={{ backgroundColor: '#0000ff' }}
                onClick={() => setColor('#0000ff')}
              />
              <ColorOption
                style={{ backgroundColor: '#ffff00' }}
                onClick={() => setColor('#ffff00')}
              />
            </ColorPicker>
          </InputField>
          <div>
            <Button type="submit">Add</Button>
            <CancelButton type="button" onClick={handleCancel}>Cancel</CancelButton>
          </div>
        </form>
      </FormContainer>
    </Overlay>
  );
};

export default PopupForm;
