import React, { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import CalendarTable from './CalendarTable';
import TeamTable from './TeamTable';
import HomePage from './HomePage';
import UpdateTimesheet from './UpdateTimesheet';
import ViewTimesheet from './ViewTimesheet';
import axios from 'axios';

const Dashboard = ({ empid, employeeName,email}) => {
  useEffect(() => {
    if (empid) {
      axios.get(`http://127.0.0.1:8000/api/employee-details/${empid}`)
        .then(response => {
          // Assuming the API response contains the employee name.
          // This state update should be handled in the parent component (App.js).
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
        });
    }
  }, [empid]);

  return (
    <div className="dashboard-container">
      <div className="main-content">
        <Routes>
        <Route path="/profile" element={<HomePage empid={empid} employeeName={employeeName} email={email}/>} />
          <Route path="update-timesheet" element={<UpdateTimesheet />} />
          <Route path="view-timesheet" element={<ViewTimesheet empid={empid} />} />
          <Route path="/calendar" element={<CalendarTable empid={empid} employeeName={employeeName} />} />
          <Route path="teamtable" element={<TeamTable />} />
        </Routes>
      </div>
    </div>
  );
};

export default Dashboard;
