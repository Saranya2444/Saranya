import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Employee = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    // Fetch employees from the backend
    axios.get('http://127.0.0.1:8000/api/employee-details/')
      .then(response => {
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the employees!', error);
      });
  }, []);

  const handleAddClick = (employeeId) => {
    // Handle add button click
    console.log(`Add button clicked for employee ID: ${employeeId}`);
    // You can redirect to another page, open a modal, or make another API call here
  };

  return (
    <div>
      <h1>Employee List</h1>
      <ul>
        {employees.map(employee => (
          <li key={employee.emp_id}>
            {employee.employee_name} - {employee.employee_id}
            <button onClick={() => handleAddClick(employee.id)}>Add</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Employee;
