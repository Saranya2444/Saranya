import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ProjectPage = () => {
    const [projects, setProjects] = useState([]);
    const [selectedProject, setSelectedProject] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('http://127.0.0.1:8000/api/projects/')
            .then(response => setProjects(response.data))
            .catch(error => console.error('Error fetching projects:', error));
    }, []);

    const handleProjectClick = (project) => {
        setSelectedProject(project);
    };

    const handleAddButtonClick = () => {
        navigate('/add-project');  // Navigate to the project form page
    };

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h1>Project List</h1>
                <button onClick={handleAddButtonClick}>Add Project</button>
            </div>
            <ul>
                {projects.map(project => (
                    <li key={project.id} onClick={() => handleProjectClick(project)}>
                        {project.project_name}
                    </li>
                ))}
            </ul>
            {selectedProject && (
                <div>
                    <h2>Project Details</h2>
                    <p><strong>Manager:</strong> {selectedProject.emp_id}</p>
                    <p><strong>Assigned to Lead:</strong> {selectedProject.assigned_to_lead}</p>
                    <p><strong>Project Name:</strong> {selectedProject.project_name}</p>
                    <p><strong>Project Module:</strong> {selectedProject.project_module}</p>
                    <p><strong>Status:</strong> {selectedProject.status}</p>
                </div>
            )}
        </div>
    );
};

export default ProjectPage;
