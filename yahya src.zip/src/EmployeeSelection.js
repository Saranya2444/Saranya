import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EmployeeSelection = () => {
    const [employees, setEmployees] = useState([]);
    const [selectedEmployees, setSelectedEmployees] = useState([]);

    useEffect(() => {
        // Fetch employees from the backend
        const fetchEmployees = async () => {
            try {
                const response = await axios.get('/api/employees/');
                setEmployees(response.data);
            } catch (error) {
                console.error('Error fetching employees:', error);
            }
        };

        fetchEmployees();
    }, []);

    const handleAddEmployee = (employeeId) => {
        if (!selectedEmployees.includes(employeeId)) {
            setSelectedEmployees([...selectedEmployees, employeeId]);
        }
    };

    const handleAddProject = async () => {
        const projectData = JSON.parse(sessionStorage.getItem('projectData'));

        const finalProjectData = {
            ...projectData,
            assigned_to_employees: selectedEmployees
        };

        try {
            await axios.post('http://127.0.0.1:8000/api/api/projects/', finalProjectData);
            alert('Project added successfully!');
        } catch (error) {
            console.error('Error adding project:', error);
        }
    };

    return (
        <div>
            <h2>Select Employees for the Project</h2>
            <ul>
                {employees.map((employee) => (
                    <li key={employee.id}>
                        {employee.name} - {employee.employee_id}
                        <button onClick={() => handleAddEmployee(employee.id)}>Add</button>
                    </li>
                ))}
            </ul>
            <button onClick={handleAddProject}>Add Project</button>
        </div>
    );
};

export default EmployeeSelection;
