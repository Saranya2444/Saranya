import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ProjectForm.css';

const ProjectForm = () => {
    const [managers, setManagers] = useState([]);
    const [leads, setLeads] = useState([]);
    const [formData, setFormData] = useState({
        emp_id: '',
        assigned_to_lead: '',
        project_name: '',
        project_module: '',
        status: 'pending'
    });
    const [successMessage, setSuccessMessage] = useState(''); // State to store success message

    useEffect(() => {
        axios.get('/api/users/?position=manager')
            .then(response => setManagers(response.data))
            .catch(error => console.error('Error fetching managers:', error));

        axios.get('/api/users/?position=lead')
            .then(response => setLeads(response.data))
            .catch(error => console.error('Error fetching leads:', error));
    }, []);

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const url = 'http://127.0.0.1:8000/api/projects/';
        
        axios.post(url, formData, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            console.log('Project created:', response.data);
            setSuccessMessage('Project created successfully!'); // Set the success message
            // Optionally, clear the form or redirect the user
            setFormData({
                emp_id: '',
                assigned_to_lead: '',
                project_name: '',
                project_module: '',
                status: 'pending'
            });
        })
        .catch(error => {
            console.error('Error creating project:', error);
            if (error.response) {
                console.log('Error response data:', error.response.data);
            }
        });
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Manager:</label>
                    <input
                        type="text"
                        name="emp_id"
                        value={formData.emp_id}
                        onChange={handleChange}
                    />
                </div>

                <div>
                    <label>Assigned to Lead:</label>
                    <input
                        type="text"
                        name="assigned_to_lead"
                        value={formData.assigned_to_lead}
                        onChange={handleChange}
                    />
                </div>

                <div>
                    <label>Project Name:</label>
                    <input
                        type="text"
                        name="project_name"
                        value={formData.project_name}
                        onChange={handleChange}
                    />
                </div>

                <div>
                    <label>Project Module:</label>
                    <input
                        type="text"
                        name="project_module"
                        value={formData.project_module}
                        onChange={handleChange}
                    />
                </div>

                <button type="submit">Create Project</button>
            </form>
            
            {/* Display the success message */}
            {successMessage && <p style={{ color: 'green', marginTop: '10px' }}>{successMessage}</p>}
        </div>
    );
};

export default ProjectForm;
