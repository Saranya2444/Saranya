from django.shortcuts import render

from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from .models import User, EmployeeDetail
from .serializers import RegisterSerializer, EmployeeDetailSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.decorators import api_view, permission_classes

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response({"message": "You have successfully registered"}, status=status.HTTP_201_CREATED)

class EmployeeDetailView(generics.ListCreateAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)

class EmployeeDetailByEmpIDView(generics.RetrieveAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)
    lookup_field = 'emp_id'


