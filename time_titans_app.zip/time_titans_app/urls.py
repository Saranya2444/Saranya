from django.urls import path
from .views import RegisterView,  EmployeeDetailView, EmployeeDetailByEmpIDView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('employee-details/', EmployeeDetailView.as_view(), name='employee_details'),
    path('employee-details/<str:emp_id>/', EmployeeDetailByEmpIDView.as_view(), name='employee_detail_by_emp_id'),
]
