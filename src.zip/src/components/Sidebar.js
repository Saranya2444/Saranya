import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { FaTachometerAlt, FaClipboard, FaUser, FaInfoCircle } from 'react-icons/fa';

const SidebarContainer = styled.div`
  width: 250px;
  height: 100vh;
  background-color: #538392;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 20px;
`;

const IconLink = styled(Link)`
  color: white;
  margin: 15px 0;
  font-size: 24px;
  text-decoration: none;

  &:hover {
    color: #80B9AD;
  }
`;

const Sidebar = () => {
  return (
    <SidebarContainer>
      <IconLink to="/dashboard"><FaTachometerAlt /></IconLink>
      <IconLink to="/timesheet"><FaClipboard /></IconLink>
      <IconLink to="/employeedetail"><FaUser /></IconLink>
      <IconLink to="/personalinformation"><FaInfoCircle /></IconLink>
    </SidebarContainer>
  );
};

export default Sidebar;
