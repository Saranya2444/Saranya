import React, { useState, useEffect } from 'react';
import timesheetService from '../services/timesheetService';
import './ViewTimesheet.css';

function ViewTimesheet() {
    const [timesheets, setTimesheets] = useState([]);
    const [filteredTimesheets, setFilteredTimesheets] = useState([]);
    const [selectedDate, setSelectedDate] = useState(null);

    useEffect(() => {
        loadTimesheets();
    }, []);

    const loadTimesheets = async () => {
        const response = await timesheetService.getTimesheets();
        setTimesheets(response.data);
        setFilteredTimesheets(response.data);
    };

    const handleDateChange = (e) => {
        const date = new Date(e.target.value);
        const formattedDate = date.toISOString().split('T')[0];
        setSelectedDate(formattedDate);

        const filtered = timesheets.filter(t => t.date === formattedDate);
        setFilteredTimesheets(filtered);
    };

    const handleShowAll = () => {
        setSelectedDate(null);
        setFilteredTimesheets(timesheets);
    };

    const renderTimesheetDetails = () => {
        if (!filteredTimesheets.length) return <p>No entries available</p>;

        return (
            <div className="timesheet-details">
                <h3>{selectedDate ? `Timesheet Details for ${selectedDate}` : 'All Timesheet Entries'}</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Project Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Total Hours</th>
                            <th>Comments</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTimesheets.map((entry, idx) => (
                            <tr key={idx}>
                                <td>{entry.emp_id}</td>
                                <td>{entry.emp_name}</td>
                                <td>{entry.project_name}</td>
                                <td>{entry.start_time}</td>
                                <td>{entry.end_time}</td>
                                <td>{entry.total_hours}</td>
                                <td>{entry.comments}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };

    return (
        <div className="view-timesheet-container">
            <h2>Timesheet Entries</h2>
            <div className="date-selector">
                <input
                    type="date"
                    onChange={handleDateChange}
                />
                <button onClick={handleShowAll}>Show All</button>
            </div>
            {renderTimesheetDetails()}
        </div>
    );
}

export default ViewTimesheet;
