import React, { useState } from 'react';
import axios from 'axios';
import './UpdateTimesheet.css';
const UpdateTimesheet = () => {
  const [formData, setFormData] = useState({
    emp_id: '',
    employee_name: '',
    start_time: '',
    end_time: '',
    project_name: '',
    total_hours_worked: '',
  });
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://127.0.0.1:8000/api/timesheets/', formData) // Adjust the endpoint based on your backend
      .then(response => {
        alert('Timesheet added successfully');
        setFormData({
          emp_id: '',
          employee_name: '',
          start_time: '',
          end_time: '',
          project_name: '',
          total_hours_worked: '',
        });
      })
      .catch(error => {
        console.error('Error adding timesheet:', error);
      });
  };
  return (
    <div className="update-timesheet-container">
      <h2>Update Timesheet</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Employee ID:
          <input type="text" name="emp_id" value={formData.emp_id} onChange={handleChange} required />
        </label>
        <label>
          Employee Name:
          <input type="text" name="employee_name" value={formData.employee_name} onChange={handleChange} required />
        </label>
        <label>
          Start Time:
          <input type="time" name="start_time" value={formData.start_time} onChange={handleChange} required />
        </label>
        <label>
          End Time:
          <input type="time" name="end_time" value={formData.end_time} onChange={handleChange} required />
        </label>
        <label>
          Project Name:
          <input type="text" name="project_name" value={formData.project_name} onChange={handleChange} required />
        </label>
        <label>
          Total Hours Worked:
          <input type="number" name="total_hours_worked" step="0.01" value={formData.total_hours_worked} onChange={handleChange} required />
        </label>
        <button type="submit">Add</button>
      </form>
    </div>
  );
};
export default UpdateTimesheet;