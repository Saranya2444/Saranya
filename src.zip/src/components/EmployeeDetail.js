import React from 'react';

const EmployeeDetail = () => {
  return <div>Employee Detail Page</div>;
};

export default EmployeeDetail;
