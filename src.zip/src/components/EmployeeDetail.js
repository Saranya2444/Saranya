import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
const EmployeeDetail = ({ onStatusChange }) => { // Accept onStatusChange as a prop
  const { id } = useParams(); // Get employeeId from URL params
  const [employeeDetail, setEmployeeDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    if (id) { // Check if id is provided
      // Fetch the employee details from the API
      axios.get(`http://127.0.0.1:8000/api/employee-details/${id}/`)
        .then(response => {
          console.log('Employee data:', response.data);
          setEmployeeDetail(response.data);
          setLoading(false);
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
          setError('There was an error fetching the employee details.');
          setLoading(false);
        });
    }
  }, [id]);
  const handleApprovalChange = (employeeId, status) => {
    // Update manager approval status in the backend
    axios.patch(`http://127.0.0.1:8000/api/employee-details/${employeeId}/`, {
      manager_approval: status
    })
      .then(response => {
        console.log('Approval updated:', response.data);
        setEmployeeDetail(prevState => ({
          ...prevState,
          manager_approval: status
        }));
        onStatusChange(employeeId, status); // Notify parent component of the status change
      })
      .catch(error => {
        console.error('There was an error updating the approval status!', error);
        setError('There was an error updating the approval status.');
      });
  };
  if (loading) {
    return <div>Loading...</div>;
  }
  if (error) {
    return <div>{error}</div>;
  }
  
  return (
    <div>
      <h2>Employee Details</h2>
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Emp ID</th>
            <th>Date</th> 
            <th>Start Time</th>
            <th>End Time</th>
            <th>Project Name</th>
            <th>Total Worked Hours</th>
            <th>Lead Approval</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{employeeDetail.employee_name}</td>
            <td>{employeeDetail.emp_id}</td>
            <td>{employeeDetail.date}</td>
            <td>{employeeDetail.start_time}</td>
            <td>{employeeDetail.end_time}</td>
            <td>{employeeDetail.project_name}</td>
            <td>{employeeDetail.total_hours_worked}</td>
            <td>
              <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'approved')}>Approve</button>
              <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'rejected')}>Reject</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};
export default EmployeeDetail;