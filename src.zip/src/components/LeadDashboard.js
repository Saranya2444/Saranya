import React from 'react';

const LeadDashboard = () => {
  return <div>Lead Dashboard</div>;
};

export default LeadDashboard;