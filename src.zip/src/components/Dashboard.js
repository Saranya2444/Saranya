import React, { useState } from 'react';
import Calendar from './Calendar';
import PopupForm from './PopupForm';

const Dashboard = () => {
  const [showPopup, setShowPopup] = useState(false);

  const handleDateClick = (date) => {
    console.log('Date clicked:', date);
    setShowPopup(true);
  };

  const closePopup = () => {
    setShowPopup(false);
  };

  return (
    <div>
      <h1>Dashboard</h1>
      {showPopup && <PopupForm onClose={closePopup} />}
      <Calendar onDateClick={handleDateClick} />
    </div>
  );
};

export default Dashboard;
