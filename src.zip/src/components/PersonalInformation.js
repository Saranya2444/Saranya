import React from 'react';

const PersonalInformation = () => {
  return <div>Personal Information Page</div>;
};

export default PersonalInformation;
