import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Profile.css';
const Profile = () => {
  const [profile, setProfile] = useState({});
  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/login/') // Adjust the endpoint based on your backend
      .then(response => {
        if (response.data.length > 0) {
          setProfile(response.data[0]);
        }
      })
      .catch(error => {
        console.error('Error fetching profile:', error);
      });
  }, []);
  return (
    <div className="profile-container">
      <h2>Profile</h2>
      <p><strong>Employee ID:</strong> {profile.emp_id}</p>
      <p><strong>Employee Name:</strong> {profile.employee_name}</p>
    </div>
  );
};
export default Profile;