import React from 'react';
import styled from 'styled-components';
import { FaPlus } from 'react-icons/fa';

const CalendarContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 10px;
  padding: 20px;
  background-color: #6295A2;
`;

const DateBox = styled.div`
  background-color: #80B9AD;
  padding: 10px;
  text-align: center;
  position: relative;
  border-radius: 5px;
`;

const AddIcon = styled(FaPlus)`
  color: #538392;
  cursor: pointer;
  position: absolute;
  bottom: 5px;
  right: 5px;

  &:hover {
    color: #80B9AD;
  }
`;

const Calendar = ({ onDateClick }) => {
  const dates = Array.from({ length: 30 }, (_, i) => i + 1);

  return (
    <CalendarContainer>
      {dates.map(date => (
        <DateBox key={date}>
          {date}
          <AddIcon onClick={() => onDateClick(date)} />
        </DateBox>
      ))}
    </CalendarContainer>
  );
};

export default Calendar;
