// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import UpdateTimesheet from './components/UpdateTimesheet';
import ViewTimesheet from './components/ViewTimesheet';
import Register from './components/Register';
import Login from './components/Login';
import { AuthProvider, useAuth } from './context/AuthContext';
import './App.css';

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="app">
          <Content />
        </div>
      </Router>
    </AuthProvider>
  );
};

const Content = () => {
  const { empId } = useAuth();

  return (
    <>
      {empId && <Sidebar />}
      <div className={empId ? 'content' : ''}>
        <Routes>
          <Route path="/" element={<Navigate to="/register" />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          {empId && (
            <>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/update-timesheet" element={<UpdateTimesheet />} />
              <Route path="/view-timesheet" element={<ViewTimesheet />} />
            </>
          )}
          <Route path="*" element={<Navigate to={empId ? "/dashboard" : "/login"} />} />
        </Routes>
      </div>
    </>
  );
};

export default App;
