import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Timesheet from './components/Timesheet';
import EmployeeDetail from './components/EmployeeDetail';
import PersonalInformation from './components/PersonalInformation';
import styled from 'styled-components';

const Container = styled.div`
  display: flex;
`;

const PageContent = styled.div`
  flex: 1;
  padding: 20px;
  background-color: #6295A2;
`;

const App = () => {
  return (
    <Router>
      <Container>
        <Sidebar />
        <PageContent>
          <Switch>
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/timesheet" component={Timesheet} />
            <Route path="/employeedetail" component={EmployeeDetail} />
            <Route path="/personalinformation" component={PersonalInformation} />
          </Switch>
        </PageContent>
      </Container>
    </Router>
  );
};

export default App;
