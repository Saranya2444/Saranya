from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from django.http import JsonResponse
from django.contrib.auth.hashers import make_password, check_password
from django.views.decorators.http import require_GET
from .models import MyUser, EmployeeDetail, TimeSheet,ManagerSheet,TeamleaderSheet
from .serializers import *
from django.db import IntegrityError
from rest_framework.permissions import AllowAny
from rest_framework import generics


# class RegisterView(CreateAPIView):
#     serializer_class = MyUserSerializer
#     def post(self, request):
#         serializer = MyUserSerializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         serializer.save()
#         return Response(serializer.data, status=status.HTTP_201_CREATED)
    

class RegisterView(generics.CreateAPIView):
    permission_classes = (AllowAny,)
    serializer_class = MyUserSerializer

    def create(self, request, *args, **kwargs):
        data = request.data.get('users', [])
        errors = []
        success_count = 0

        for user_data in data:
            serializer = MyUserSerializer(data=user_data)
            if serializer.is_valid():
                try:
                    user = serializer.save()
                    user.set_password(user_data['password'])
                    user.save()
                    success_count += 1
                except IntegrityError as e:
                    error_message = str(e)
                    field = "unknown"
                    if "email" in error_message:
                        field = "email"
                    elif "userid" in error_message:
                        field = "userid"
                    errors.append({
                        "email": user_data.get('email'),
                        "error": f"UNIQUE constraint failed on {field}"
                    })
            else:
                errors.append({
                    "email": user_data.get('email'),
                    "errors": serializer.errors
                })

        if errors:
            return Response({"success_count": success_count, "errors": errors}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"message": "All users created successfully"}, status=status.HTTP_201_CREATED)

class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        userid = serializer.validated_data['userid']
        password = serializer.validated_data['password']
        print("Test: ",userid,password)
        try:
            user = MyUser.objects.get(userid=userid)
            print(user)
            if check_password(password, user.password):
                personstatus = getattr(user, 'personstatus', None)
                print(personstatus)
                response_data = {
                    'userid': userid,
                    'personstatus': personstatus
                }
                if personstatus == 'Employee':
                    response_data['redirect_url'] = '/employee-dashboard/'
                elif personstatus == 'Lead':
                    response_data['redirect_url'] = '/lead-dashboard/'
                elif personstatus == 'Manager':
                    response_data['redirect_url'] = '/manager-dashboard/'
                else:
                    return Response({'error': 'Unknown person status'}, status=status.HTTP_400_BAD_REQUEST)
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)
        except:
            # Fallback response to ensure every code path returns a Response
            return Response({"error": "Employee not found"}, status=status.HTTP_404_NOT_FOUND)
class ChangePasswordView(APIView):
    def post(self, request):
        userid = request.data.get('userid')
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        user = MyUser.objects.filter(userid=userid).first()
        if user and user.check_password(old_password):
            user.set_password(new_password)
            user.save()
            return Response({'status': 'password changed'}, status=status.HTTP_200_OK)
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

# class EmployeeDetailView(APIView):
#     def get(self, request):
#         employee_id = request.query_params.get('employee_id')
#         print(employee_id)
#         if employee_id:
#             try:
#                 employee = MyUser.objects.get(userid=employee_id)
#                 print(employee)
#                 employee_details = MyUser.objects.filter(userid=employee).first()
#                 print(employee_details)
#                 if employee_details.exists():
#                     serializer = EmployeeDetailSerializer(employee_details, many=True)
#                     return Response(serializer.data, status=status.HTTP_200_OK)
#                 return Response({'error': 'Employee detail not found'}, status=status.HTTP_404_NOT_FOUND)
#             except MyUser.DoesNotExist:
#                 return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
#         else:
#             employees = MyUser.objects.all()
#             serializer = MyUserSerializer(employees, many=True)
#             return Response(serializer.data, status=status.HTTP_200_OK)


class EmployeeDetailView(APIView):
    def get(self, request):
        print(request.data)
        employee_id = request.query_params.get('employee_id')
        print(employee_id)
        if employee_id:
            try:
                employee = MyUser.objects.get(userid=employee_id)
                employee_details = EmployeeDetail.objects.filter(employee=employee).first()
                if employee_details:
                    serializer = EmployeeDetailSerializer(employee_details)
                    return Response(serializer.data, status=status.HTTP_200_OK)
                return Response({'error': 'Employee detail not found'}, status=status.HTTP_404_NOT_FOUND)
            except MyUser.DoesNotExist:
                return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        else:
            employees = MyUser.objects.all()
            serializer = MyUserSerializer(employees, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        print('here')
        serializer = EmployeeDetailSerializer(data=request.data)
        print(request.data)
        print(serializer.is_valid())
        if serializer.is_valid():
            try:
                employee = MyUser.objects.get(userid=request.data['employee'])
                project_name = ManagerSheet.objects.get(project_name=request.data['project_name'])
                module_name = TeamleaderSheet.objects.get(module_name=request.data['module_name'])
                serializer.save(employee=employee, project_name=project_name, module_name=module_name)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            except (MyUser.DoesNotExist, ManagerSheet.DoesNotExist, TeamleaderSheet.DoesNotExist):
                return Response({'error': 'Data not found'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class TimeSheetViewSet(viewsets.ModelViewSet):
    queryset = TimeSheet.objects.all()
    serializer_class = TimeSheetSerializer

    # @action(detail=False, methods=['post'])
    # def add(self, request):
    #     data = request.data
    #     print("Received data:", data)
        
    #     employee_id = data.get('id')
    #     project_name = data.get('project_name')  # Retrieve project_name from request data
    #     module_name = data.get('module_name')  
         
    #     try:
    #         employee = MyUser.objects.get(userid=employee_id)
    #         print('pass')
    #     except MyUser.DoesNotExist:
    #         return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        
    #     # Modify the data to include the employee ID directly
    #     data['employee'] = employee.id
    #     data['manager_approval'] = 'Pending'
    #     data['project_name'] =ManagerSheet.objects.get(project_name = project_name)
    #     data['module_name'] = TeamleaderSheet.objects.get(module_name = module_name)
    #     print("Data after adding employee:", data)
        
    #     print('updated :',data)
    #     serializer = self.get_serializer(data=data)
    #     print("Serializer valid:", serializer.is_valid())
        
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data, status=status.HTTP_201_CREATED)
        
    #     print("Serializer errors:", serializer.errors)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    @action(detail=False, methods=['post'])
    def add(self, request):
        data = request.data
        print("Received data:", data)
        
        employee_id = data.get('id')
        project_name_id = data.get('project_name')  # Expecting primary key
        module_name_id = data.get('module_name')    # Expecting primary key
        print(module_name_id)
        
        try:
            print('pass1')
            employee = MyUser.objects.get(userid=employee_id)
            print('pass2')
            project = ManagerSheet.objects.get(project_name=project_name_id)
            print('pass3')
            module = TeamleaderSheet.objects.get(module_name=module_name_id)
            print(module)
        except (MyUser.DoesNotExist, ManagerSheet.DoesNotExist, TeamleaderSheet.DoesNotExist):
            return Response({'error': 'Data not found'}, status=status.HTTP_400_BAD_REQUEST)
        
        # data['employee'] = int(employee.userid)
        # data['id'] = int(data['id'])
        # # data['id'] = int(data['id'])  # Ensure ID is an integer
        # data['week'] = data.get('week') # Convert week to integer
        # data['total'] = int(data.get('total'))  # Convert total to integer
        # data['tue'] = int(data.get('tue') ) # Convert to integer
        # data['wed'] = int(data.get('wed'))  # Convert to integer
        # data['thu'] = int(data.get('thu') ) # Convert to integer
        # data['fri'] = int(data.get('fri') ) # Convert to integer
        # data['mon'] = int(data.get('mon') ) # Convert to integer
        # data['manager_approval'] = 'Pending'
        # data['project_name'] = project.project_name
        # data['module_name'] = module.module_name
        # data['leave_days'] = 0
        # data.pop('id')
        # data.pop('team_name')



        data1 = {
            "project_name": project.project_name,
            "module_name": module.userid,
            "employee": employee.id,
            "week": data.get('week'),
            "mon": int(data.get('mon') ),
            "tue": int(data.get('tue') ),
            "wed": int(data.get('wed') ),
            "thu": int(data.get('thu') ),
            "fri": int(data.get('fri') ),
            "total": int(data.get('total') ),
            "leave_days": 0,
            "lead_approval": 'Pending',
            "manager_approval": 'Pending'
        }
        print('updated',data1,'\n\n\n')
        serializer = self.get_serializer(data=data1)
        print(serializer.is_valid)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)






    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Approved'
        timesheet.save()
        return Response({'status': 'Timesheet approved by Lead'}, status=status.HTTP_200_OK)
   
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Rejected'
        timesheet.save()
        return Response({'status': 'Timesheet rejected by Lead'}, status=status.HTTP_200_OK)
    @action(detail=True, methods=['post'])
    def manager_approve(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.manager_approval = 'Approved'
        timesheet.save()
        return Response({'status': 'Timesheet approved by Manager'}, status=status.HTTP_200_OK)
    
    
    @action(detail=True, methods=['post'])
    def manager_reject(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.manager_approval = 'Rejected'
        timesheet.save()
        return Response({'status': 'Timesheet rejected by Manager'}, status=status.HTTP_200_OK)
    

    def perform_create(self, serializer):
        timesheet = serializer.save()
        self.calculate_leave_days(timesheet)

    def perform_update(self, serializer):
        timesheet = serializer.save()
        self.calculate_leave_days(timesheet)

    def calculate_leave_days(self, timesheet):
        leave_days = 0
        days = [timesheet.mon, timesheet.tue, timesheet.wed, timesheet.thu, timesheet.fri]
        for day in days:
            if day == 0:
                leave_days += 1
        timesheet.total = sum(days)
        timesheet.save()
    @action(detail=False, methods=['get'])
    def user_timesheets(self, request):
        print(request.data)
        user_id = request.query_params.get('user_id')
        print('User ID:', user_id)  # Log user_id to check if it is being retrieved correctly
        
        if user_id:
            timesheets = TimeSheet.objects.filter(employee__userid=user_id)
        else:
            timesheets = TimeSheet.objects.all()

        serializer = self.get_serializer(timesheets, many=True)
        return Response(serializer.data)
       

# class ManagerSheetViewSet(viewsets.ModelViewSet):
#     queryset = ManagerSheet.objects.all()
#     serializer_class = ManagerSheetSerializer
#     permission_classes = [AllowAny]

#     def create(self, request, *args, **kwargs):
#         print('hello')
#         print('Request data:', request.data)  # Debugging line
#         employee_id =MyUser.objects.filter(personstatus='Lead')
#         print('Employee ID:', employee_id)  # Debugging line

#         if not employee_id:
#             return Response({"error": "Employee field is required."}, status=status.HTTP_400_BAD_REQUEST)

#         try:
#             team_leader = MyUser.objects.get(userid=employee_id, personstatus='Lead')
#         except MyUser.DoesNotExist:
#             return Response({"error": "Team leader not found."}, status=status.HTTP_404_NOT_FOUND)
    
#         if ManagerSheet.objects.filter(team_leader=team_leader).exists():
#             return Response({"error": "This team leader already has an assigned project."}, status=status.HTTP_400_BAD_REQUEST)
    
#         serializer =TeamleaderSheetSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         else:
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ManagerSheetViewSet(viewsets.ModelViewSet):
    queryset = ManagerSheet.objects.all()
    serializer_class = ManagerSheetSerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        print('hello')
        print('Request data:', request.data)  # Debugging line

        # Extract team_leader ID from request data
        team_leader_id = request.data.get('team_leader')
        if not team_leader_id:
            return Response({"error": "Team leader ID is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            team_leader = MyUser.objects.get(userid=team_leader_id, personstatus='Lead')
        except MyUser.DoesNotExist:
            return Response({"error": "Team leader not found or not a Lead."}, status=status.HTTP_404_NOT_FOUND)
    
        if ManagerSheet.objects.filter(team_leader=team_leader).exists():
            return Response({"error": "This team leader already has an assigned project."}, status=status.HTTP_400_BAD_REQUEST)
    
        serializer = ManagerSheetSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class TeamleaderSheetViewSet(viewsets.ModelViewSet):
    queryset = TeamleaderSheet.objects.all()
    serializer_class = TeamleaderSheetSerializer
    
    def post(self, request, *args, **kwargs):
        userid = request.data.get('userid')
        module_name = request.data.get('module_name')
        # Check if a record with the same userid and module_name already exists
        if TeamleaderSheet.objects.filter(userid=userid, module_name=module_name).exists():
            return Response(
                {'error': 'This user is already assigned to this module.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = TeamleaderSheetSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Teamleader sheet added successfully.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class LeadUserViewSet(viewsets.ReadOnlyModelViewSet):
    print('hello')
    queryset = MyUser.objects.filter(personstatus='Lead')
    print(queryset)
    serializer_class = MyUserSerializer
