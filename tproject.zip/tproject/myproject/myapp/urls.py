# myapp/urls.py
from django.urls import path
from .views import LoginView, RegisterView, EmployeeDetailView, EmployeeDetailByEmpIDView, EmployeeListView

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),
    path('register/', RegisterView.as_view(), name='register'),
    path('employee-details/', EmployeeDetailView.as_view(), name='employee-list'),
    path('employee-details/<emp_id>/', EmployeeDetailByEmpIDView.as_view(), name='employee-detail'),
]
