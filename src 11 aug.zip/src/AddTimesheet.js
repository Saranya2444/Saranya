import React, { useState } from 'react';
import axios from 'axios';

const AddTimesheet = () => {
    const [timesheet, setTimesheet] = useState({
        employee_name: '',
        emp_id: '',
        start_time: '',
        end_time: '',
        project_name: '',
        total_hours_worked: '',
    });

    const handleChange = (e) => {
        setTimesheet({ ...timesheet, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('http://localhost:8000/api/timesheet/', timesheet);
        // Clear the form
        setTimesheet({
            employee_name: '',
            emp_id: '',
            start_time: '',
            end_time: '',
            project_name: '',
            total_hours_worked: '',
        });
    };

    return (
        <div>
            <h2>Add Timesheet</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Employee Name:</label>
                    <input type="text" name="employee_name" value={timesheet.employee_name} onChange={handleChange} />
                </div>
                <div>
                    <label>Employee ID:</label>
                    <input type="text" name="emp_id" value={timesheet.emp_id} onChange={handleChange} />
                </div>
                <div>
                    <label>Start Time:</label>
                    <input type="time" name="start_time" value={timesheet.start_time} onChange={handleChange} />
                </div>
                <div>
                    <label>End Time:</label>
                    <input type="time" name="end_time" value={timesheet.end_time} onChange={handleChange} />
                </div>
                <div>
                    <label>Project Name:</label>
                    <input type="text" name="project_name" value={timesheet.project_name} onChange={handleChange} />
                </div>
                <div>
                    <label>Total Hours Worked:</label>
                    <input type="number" name="total_hours_worked" value={timesheet.total_hours_worked} onChange={handleChange} />
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default AddTimesheet;
