import React from 'react';

const EmployeeDashboard = () => {
    return (
        <div>
            <h2> Dashboard</h2>
            <p>Welcome to the employee Dashboard!</p>
            {/* Add manager-specific components and functionalities here */}
        </div>
    );
};

export default EmployeeDashboard;
