import React, { useState, useEffect } from 'react';
import axios from 'axios';

const LeadAssignmentForm = () => {
    const [projects, setProjects] = useState([]);
    const [employees, setEmployees] = useState([]);
    const [formData, setFormData] = useState({
        project_name: '',
        assigned_to_employees: []
    });
    
    useEffect(() => {
        // Fetch projects and employees from the API
        axios.get('http://127.0.0.1:8000/api/projects/')
            .then(response => setProjects(response.data))
            .catch(error => console.error('Error fetching projects:', error));

        axios.get('http://127.0.0.1:8000/api/api/users/?position=employee')
            .then(response => setEmployees(response.data))
            .catch(error => console.error('Error fetching employees:', error));
    }, []);

    const handleChange = e => {
        const { name, value } = e.target;
        if (name === "assigned_to_employees") {
            const selectedEmployees = [...formData.assigned_to_employees];
            if (selectedEmployees.includes(value)) {
                setFormData({
                    ...formData,
                    assigned_to_employees: selectedEmployees.filter(emp => emp !== value)
                });
            } else {
                setFormData({
                    ...formData,
                    assigned_to_employees: [...selectedEmployees, value]
                });
            }
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const url = 'http://127.0.0.1:8000/api/lead-assignments/';
        
        axios.post(url, formData, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            
            alert('Employees added successfully!');
        })
            .catch(error => console.error('Error creating lead assignment:', error));
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Project Name:</label>
                <select name="project_name" value={formData.project_name} onChange={handleChange}>
                    <option value="">Select a project</option>
                    {projects.map(project => (
                        <option key={project.id} value={project.id}>
                            {project.project_name}
                        </option>
                    ))}
                </select>
            </div>

            <div>
                <label>Assign Employees:</label>
                {employees.map(employee => (
                    <div key={employee.emp_id}>
                        <input
                            type="checkbox"
                            name="assigned_to_employees"
                            value={employee.emp_id}
                            checked={formData.assigned_to_employees.includes(employee.emp_id)}
                            onChange={handleChange}
                        />
                        {employee.emp_id}
                    </div>
                ))}
            </div>

            <button type="submit">Assign Employees</button>
        </form>
    );
};

export default LeadAssignmentForm;
