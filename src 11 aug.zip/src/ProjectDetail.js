import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const ProjectDetail = () => {
    const { id } = useParams();
    const [project, setProject] = useState(null);

    useEffect(() => {
        axios.get(`http://127.0.0.1:8000/api/projects/${id}/`)
            .then(response => setProject(response.data))
            .catch(error => console.error('Error fetching project details:', error));
    }, [id]);

    if (!project) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h2>{project.project_name}</h2>
            <p><strong>Manager:</strong> {project.emp_id}</p>
            <p><strong>Assigned to Lead:</strong> {project.assigned_to_lead}</p>
            <p><strong>Module:</strong> {project.project_module}</p>
            <p><strong>Status:</strong> {project.status}</p>
            <p><strong>Timestamp:</strong> {project.timestamp}</p>
        </div>
    );
};

export default ProjectDetail;
