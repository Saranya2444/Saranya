import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
//import './Emp.css';
const Emp = () => {
  const { empId } = useParams();
  const [employee, setEmployee] = useState(null);
  const [leaveDays, setLeaveDays] = useState(0);
  const [timesheet, setTimesheet] = useState([]);
  const [monthlySalary, setMonthlySalary] = useState(0);
  const [joiningDate, setJoiningDate] =useState('');
  const [employeeDetail, setEmployeeDetail] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
 // const employeeDetailData=[];
 useEffect(() => {
  axios.get(`http://127.0.0.1:8000/api/employee-details/${empId}/`)
    .then(response => {
      const user = response.data;
      console.log(user)
      
      const employeeDetailData = user.employeeDetail || [];
      
      const joiningDate = user.joining_date ||'';
     
      setEmployee(user);
      setEmployeeDetail(employeeDetailData);
      setJoiningDate(joiningDate)
      // Calculate leave days and salary
      const { workingDays, leaveDays, salary } = calculateDaysAndSalary(employeeDetailData, joiningDate);
      setLeaveDays(leaveDays);
      console.log(salary)
      setMonthlySalary(salary.toFixed(2));
    })
    .catch(error => {
      console.error('Error fetching employee details:', error);
    });
}, [empId]);
useEffect(() => {
  if (empId) {
    axios.get(`http://127.0.0.1:8000/api/employee-details/${empId}/`)
      .then(response => {
        setEmployeeDetail(response.data);
        setLoading(false);
      })
      .catch(error => {
        setError('There was an error fetching the employee details.');
        setLoading(false);
      });
  }
}, [empId]);
  
  const calculateDaysAndSalary = (employeeDetailData, joiningDate) => {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth(); // 0-indexed
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const workingDays = [...Array(daysInMonth).keys()]
      .map((day) => new Date(currentYear, currentMonth, day + 1))
      .filter((date) => date.getDay() !== 0).length; // Remove Sundays
    const uniqueDaysWithTimesheets = new Set(
      employeeDetailData
        .filter(entry => {
          const entryDate = new Date(entry.date);
          return entryDate >= new Date(joiningDate) && 
                 entryDate.getMonth() === currentMonth && 
                 entryDate.getFullYear() === currentYear;
        })
        .map(entry => new Date(entry.date).toISOString().split("T")[0])
    );
    const leaveDays = workingDays - uniqueDaysWithTimesheets.size;
    // Calculate total working hours and salary
    const totalHours = employeeDetailData.reduce(
      (acc, employeeDetail) => acc + parseFloat(employeeDetail.total_hours),
      0
    );
    const salary = totalHours * 200; // Assuming 200 rupees per hour
    return { workingDays, leaveDays, salary };
  };
  if (!employee) {
    return <p>Loading...</p>;
  }
  return (
    <div className="employee-details">
      <p>Welcome, {employee.emp_id}</p>
      <p>Leave Days: {leaveDays}</p>
      <p>Monthly Salary: ₹{employeeDetail.total_hours_worked*500}</p><br/>
      <h3>Timesheet Details</h3>
      <table border={1}>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Date</th>
            <th>Total Working Hours</th>
          </tr>
        </thead>
        <tbody>
             <tr>
              <td>{employeeDetail.employee_name}</td>
              <td>{employeeDetail.date}</td>
              <td>{employeeDetail.total_hours_worked}</td>
            </tr>
        </tbody>
      </table>
      {error && <p className="error-message">{error}</p>}
    </div>
  );
};
export default Emp;