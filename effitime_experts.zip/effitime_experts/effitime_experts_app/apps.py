from django.apps import AppConfig


class EffitimeExpertsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'effitime_experts_app'
