from django.apps import AppConfig

class TechArmyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tech_army_app'
