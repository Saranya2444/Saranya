from rest_framework import serializers
from .models import User, EmployeeDetail, Project
from django.contrib.auth.password_validation import validate_password

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    joining_date = serializers.DateField()

    class Meta:
        model = User
        fields = ('username', 'email', 'emp_id', 'position', 'joining_date', 'password')

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            emp_id=validated_data['emp_id'],
            position=validated_data['position'],
            joining_date=validated_data['joining_date'],
            password=validated_data['password']
        )
        return user

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'emp_id', 'position', 'joining_date']
        extra_kwargs = {
            'password': {'write_only': True},
            'Time_stamp': {'read_only': True},
            'joining_date': {'read_only': True}
        }

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            emp_id=validated_data['emp_id'],
            position=validated_data['position'],
            password=validated_data['password']
        )
        return user

class EmployeeDetailSerializer(serializers.ModelSerializer):
    emp_id = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    emp_id_display = serializers.CharField(source='emp_id.emp_id', read_only=True)

    class Meta:
        model = EmployeeDetail
        fields = '__all__'
        read_only_fields = ('project_name',)

    def update(self, instance, validated_data):
        instance.lead_approval = validated_data.get('lead_approval', instance.lead_approval)
        instance.manager_approval = validated_data.get('manager_approval', instance.manager_approval)
        instance.save()
        return instance

class LoginSerializer(serializers.Serializer):
    emp_id = serializers.CharField()
    password = serializers.CharField(write_only=True)

class ProjectSerializer(serializers.ModelSerializer):
    emp_id = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    emp_id_display = serializers.CharField(source='emp_id.emp_id', read_only=True)
    assigned_to_lead = serializers.PrimaryKeyRelatedField(queryset=User.objects.filter(position='lead'), required=False, allow_null=True)
    assigned_to_employees = serializers.PrimaryKeyRelatedField(queryset=User.objects.filter(position='employee').exclude(assigned_employee_projects__isnull=False), many=True, required=False)

    class Meta:
        model = Project
        fields = ['emp_id', 'project_name', 'project_module', 'status', 'timestamp', 'assigned_to_lead', 'assigned_to_employees']