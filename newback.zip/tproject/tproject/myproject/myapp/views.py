from django.http import JsonResponse
from django.shortcuts import render
from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status, generics, viewsets
from rest_framework.response import Response
from .models import LeadAssignment
from .serializers import LeadAssignmentSerializer
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
import logging
from django.utils import timezone
from datetime import timedelta
from rest_framework.views import APIView
from .models import User, EmployeeDetail,Project
from .serializers import RegisterSerializer, EmployeeDetailSerializer, LoginSerializer, UserSerializer,ProjectSerializer

logger = logging.getLogger(__name__)

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response({"message": "You have successfully registered"}, status=status.HTTP_201_CREATED)

class LoginView(generics.CreateAPIView):
    permission_classes = (AllowAny,)
    serializer_class = LoginSerializer

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        emp_id = serializer.validated_data['emp_id']
        password = serializer.validated_data['password']
        print(emp_id)
        print(password)

        try:
            user = User.objects.get(emp_id=emp_id)
            if user.check_password(password):
                position = user.position
                redirect_url = '/'
                if position == 'employee':
                    redirect_url = '/dashboard/profile/'
                elif position == 'lead':
                    redirect_url = '/lead-dashboard/'
                elif position == 'manager':
                    redirect_url = '/home/'
                return Response({'redirect_url': redirect_url}, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_400_BAD_REQUEST)

class EmployeeDetailView(generics.ListCreateAPIView):
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)

    def get_queryset(self):
        emp_id = self.request.query_params.get('emp_id', None)
        print(emp_id)
        if emp_id:
            print(emp_id)
            return EmployeeDetail.objects.filter()
        return EmployeeDetail.objects.all()

class EmployeeDetailByEmpIDView(generics.RetrieveAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)
    print(serializer_class)
    lookup_field = 'emp_id'

    def patch(self, request, *args, **kwargs):
        emp_id = self.kwargs.get('emp_id')
        print(request.data, emp_id)
        employee_detail = self.get_object()
        serializer = self.get_serializer(employee_detail, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        print(serializer.data)
        return Response(serializer.data)

class EmployeeDetailByEmpIDView1(generics.RetrieveAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = (AllowAny,)
    print(serializer_class)
    lookup_field = 'emp_id'

    def patch(self, request, *args, **kwargs):
        emp_id = self.kwargs.get('emp_id')
        print(request.data, emp_id)
        employee_detail = self.get_object()
        serializer = self.get_serializer(employee_detail, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        print(serializer.data)
        return Response(serializer.data)

class EmployeeListView(generics.ListAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer

    def get_employee_details(request):
        employee_details = list(EmployeeDetail.objects.values(
            'emp_id',
            'employee_name',
            'start_time',
            'end_time',
            'project_name',
            'lead_approval'
        ))
        print(employee_details)
        return JsonResponse(employee_details, safe=False)

class EmployeeDetailViewSet(viewsets.ModelViewSet):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    print(serializer_class)

    def update_approval(self, request, pk=None):
        try:
            print('here')
            employee = self.get_object()
            print(employee)
            serializer = EmployeeDetailSerializer(employee, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class UpdateApprovalView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, emp_id):
        try:
            print("here")
            employee_detail = EmployeeDetail.objects.get(emp_id=emp_id)
            print(employee_detail)
            action = request.data.get("action")
            print(request.data)
            print(action)
            if action not in ['approve', 'reject']:
                return Response({"error": "Invalid action"}, status=status.HTTP_400_BAD_REQUEST)
            if request.data['userRole'] == 'lead':
                employee_detail.lead_approval = 'approved' if action == 'approve' else 'rejected'
                employee_detail.save()
                return Response({"message": f"Lead approval updated to {employee_detail.lead_approval}"},
                                status=status.HTTP_200_OK)
            else:
                employee_detail.manager_approval = 'approved' if action == 'approve' else 'rejected'
                employee_detail.save()
                return Response({"message": f"Lead approval updated to {employee_detail.manager_approval}"},
                            status=status.HTTP_200_OK)
        except EmployeeDetail.DoesNotExist:
            return Response({"error": "Employee detail not found"}, status=status.HTTP_404_NOT_FOUND)
class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def update(self, request, *args, **kwargs):
        return super().update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        return super().partial_update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        return super().destroy(request, *args, **kwargs)
class LeadAssignmentListCreateView(generics.ListCreateAPIView):
    queryset = LeadAssignment.objects.all()
    serializer_class = LeadAssignmentSerializer

class LeadAssignmentDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = LeadAssignment.objects.all()
    serializer_class = LeadAssignmentSerializer

def get_users_by_position(request):
    position = request.GET.get('position')
    if position:
        users = User.objects.filter(position=position)
    else:
        users = User.objects.all()

    user_data = list(users.values('emp_id', 'username'))  # Adjust fields as needed
    return JsonResponse(user_data, safe=False)