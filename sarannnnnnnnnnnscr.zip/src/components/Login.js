// src/components/Login.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import authService from './authService';
import './Login.css';

const Login = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    userid: '',
    password: '',
  });

  const { userid, password } = formData;
  const navigate = useNavigate();

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleLogin = async (e) => {
    e.preventDefault();
    const user = { userid, password };

    try {
      // Using authService to handle login
      const res = await authService.login(userid, password);
      console.log(res.data);

      // Redirect based on user status
      if (res.data.redirect_url) {
        onLogin(); // Call the onLogin prop to set the logged-in state
        navigate(res.data.redirect_url);
      } else {
        console.error('No redirect URL found in the response');
      }
    } catch (err) {
      console.error(err.response?.data || 'Error logging in');
      alert('Error logging in');
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input
          type="text"
          name="userid"
          value={userid}
          onChange={onChange}
          placeholder="User ID"
          required
        />
        <input
          type="password"
          name="password"
          value={password}
          onChange={onChange}
          placeholder="Password"
          required
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
