import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProjectForm = () => {
    const [projectName, setProjectName] = useState('');
    const [projectModule, setProjectModule] = useState('');
    const [status, setStatus] = useState('pending');
    const [lead, setLead] = useState('');
    const [employees, setEmployees] = useState([]);
    const [empId, setEmpId] = useState(''); // Add state for emp_id
    const [allLeads, setAllLeads] = useState([]);
    const [allEmployees, setAllEmployees] = useState([]);
    const [allEmpIds, setAllEmpIds] = useState([]);

    // Fetch leads and employees from the backend
    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const leadsResponse = await axios.get('/api/users/?position=lead');
                const employeesResponse = await axios.get('/api/users/?position=employee');
                const empIdsResponse = await axios.get('/api/users'); // Fetch all users for emp_id options
                setAllLeads(leadsResponse.data);
                setAllEmployees(employeesResponse.data);
                setAllEmpIds(empIdsResponse.data); // Store all emp_ids
            } catch (error) {
                console.error('Error fetching users:', error);
            }
        };

        fetchUsers();
    }, []);

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        const projectData = {
            emp_id: empId, // Include emp_id in the project data
            project_name: projectName,
            project_module: projectModule,
            status: status,
            assigned_to_lead: lead,
            assigned_to_employees: employees
        };

        try {
            await axios.post('http://127.0.0.1:8000/api/api/projects/', projectData);
            alert('Project added successfully!');
        } catch (error) {
            console.error('Error adding project:', error);
        }
    };

    // Generate lead IDs like 1, 4, 7, ..., up to 500
    const generateLeadOptions = () => {
        let options = [];
        for (let i = 1; i <= 500; i += 3) {
            options.push(i);
        }
        return options;
    };

    // Generate employee IDs like 3, 6, 9, ..., up to 500
    const generateEmployeeOptions = () => {
        let options = [];
        for (let i = 3; i <= 500; i += 3) {
            options.push(i);
        }
        return options;
    };

    return (
        <div>
            <h2>Add New Project</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Employee ID:</label>
                    <input
                        type="text"
                        value={empId}
                        onChange={(e) => setEmpId(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Project Name:</label>
                    <input
                        type="text"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Project Module:</label>
                    <input
                        type="text"
                        value={projectModule}
                        onChange={(e) => setProjectModule(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Status:</label>
                    <select value={status} onChange={(e) => setStatus(e.target.value)}>
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                    </select>
                </div>
                <div>
                    <label>Assigned to Lead:</label>
                    <select value={lead} onChange={(e) => setLead(e.target.value)} required>
                        <option value="">Select Lead</option>
                        {generateLeadOptions().map((id) => (
                            <option key={id} value={id}>
                                {id}
                            </option>
                        ))}
                    </select>
                </div>
                <div>
                    <label>Assigned to Employees:</label>
                    <select
                        multiple
                        value={employees}
                        onChange={(e) =>
                            setEmployees([...e.target.selectedOptions].map((option) => option.value))
                        }
                    >
                        {generateEmployeeOptions().map((id) => (
                            <option key={id} value={id}>
                                {id}
                            </option>
                        ))}
                    </select>
                </div>
                <button type="submit">Add Project</button>
            </form>
        </div>
    );
};

export default ProjectForm;

