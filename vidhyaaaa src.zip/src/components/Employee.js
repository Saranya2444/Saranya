// src/pages/EmployeeList.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Employee = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    axios.get('/api/users/')
      .then(response => setEmployees(response.data))
      .catch(error => console.error('Error fetching employees:', error));
  }, []);

  const handleAdd = (emp_id) => {
    // Implement add functionality here
    axios.post('/api/projects/', { emp_id })
      .then(response => console.log('Employee added:', response))
      .catch(error => console.error('Error adding employee:', error));
  };

  return (
    <div>
      <h2>Employee List</h2>
      <ul>
        {employees.map(employee => (
          <li key={employee.emp_id}>
            {employee.username} ({employee.emp_id})
            <button onClick={() => handleAdd(employee.emp_id)}>Add</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Employee;
