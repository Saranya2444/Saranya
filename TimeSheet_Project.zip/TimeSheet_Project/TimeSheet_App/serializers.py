from rest_framework import serializers
from .models import Employee, Timesheet

from rest_framework import serializers
from .models import Employee, Timesheet
from django.contrib.auth.hashers import make_password


class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'
# class EmployeeSerializer(serializers.ModelSerializer):
#     confirm_password = serializers.CharField(write_only=True)
#
#     class Meta:
#         model = Employee
#         fields = ['emp_id', 'emp_name', 'email_id', 'password', 'confirm_password']
#         extra_kwargs = {'password': {'write_only': True}}
#
#     def validate(self, data):
#         if data['password'] != data['confirm_password']:
#             raise serializers.ValidationError("Passwords do not match.")
#         return data
#
#     def create(self, validated_data):
#         validated_data.pop('confirm_password')
#         employee = Employee.objects.create(
#             emp_id=validated_data['emp_id'],
#             emp_name=validated_data['emp_name'],
#             email_id=validated_data['email_id'],
#             password=make_password(validated_data['password'])
#         )
#         return employee


class TimesheetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Timesheet
        fields = ['emp', 'date', 'project_name', 'start_time', 'end_time', 'comments', 'total_hours']



