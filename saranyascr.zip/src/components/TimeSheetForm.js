import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TimeSheetForm = () => {
  const [userid, setUserid] = useState('');
  const [formData, setFormData] = useState({
    id: '' ,// This will be updated with the userid,
    week: '',
    mon: '',
    tue: '',
    wed: '',
    thu: '',
    fri: '',
    total: '',
    lead_approval: 'Pending'
    
  });

  useEffect(() => {
    const storedUserid = localStorage.getItem('userid');
    const storedPersonstatus = localStorage.getItem('personstatus');
    console.log('Fetched userid:', storedUserid);
    console.log('Fetched personstatus:', storedPersonstatus);
    if (storedUserid) {
        setUserid(storedUserid);
    }
  }, []);

  useEffect(() => {
    if (userid) {
      // Update formData's id when userid is available
      setFormData(prevData => ({
        ...prevData,
        id: userid
      }));
    }
  }, [userid]);

  useEffect(() => {
    const fetchEmployeeData = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/api/employee/`);
        setFormData(prevData => ({
          ...prevData,
          employee: response.data.name
        }));
      } catch (error) {
        console.error('Error fetching employee data:', error);
      }
    };

    fetchEmployeeData();
  }, []);

  useEffect(() => {
    // Calculate total hours whenever any of the daily hours change
    const totalHours = parseFloat(formData.mon || 0) +
                       parseFloat(formData.tue || 0) +
                       parseFloat(formData.wed || 0) +
                       parseFloat(formData.thu || 0) +
                       parseFloat(formData.fri || 0);
    setFormData(prevData => ({
      ...prevData,
      total: totalHours
    }));
  }, [formData.mon, formData.tue, formData.wed, formData.thu, formData.fri]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log('FormData before submission:', formData);
      const response = await axios.post(`http://127.0.0.1:8000/api/timesheet/add/`, formData);
      console.log('Timesheet submitted:', response.data);
      // Reset form or handle success message
    } catch (error) {
      console.error('Error submitting timesheet:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Employee</label>
        <input
          type="text"
          name="employee"
          value={userid}
          readOnly
        />
      </div>
      <div>
        <label>Week</label>
        <input
          type="text"
          name="week"
          value={formData.week}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Monday</label>
        <input
          type="number"
          name="mon"
          value={formData.mon}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Tuesday</label>
        <input
          type="number"
          name="tue"
          value={formData.tue}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Wednesday</label>
        <input
          type="number"
          name="wed"
          value={formData.wed}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Thursday</label>
        <input
          type="number"
          name="thu"
          value={formData.thu}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Friday</label>
        <input
          type="number"
          name="fri"
          value={formData.fri}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Total Hours</label>
        <input
          type="number"
          name="total"
          value={formData.total}
          readOnly
        />
      </div>
      <div>
        <input
          type="hidden"
          name="id"
          value={formData.id}
        />
      </div>
      <div>
        <button type="submit">Submit</button>
      </div>
    </form>
  );
};

export default TimeSheetForm;
