import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Timesheet = () => {
  const [timesheets, setTimesheets] = useState([]);

  useEffect(() => {
    // Fetch timesheet data from the backend
    axios.get('http://localhost:8000/api/timesheets/')
      .then(response => {
        setTimesheets(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the timesheet data!', error);
      });
  }, []);

  
  return (
    <div>
      <h1>Timesheets</h1>
      <table>
        <thead>
          <tr>
            <th>Employee</th>
            <th>Week</th>
            <th>Mon</th>
            <th>Tue</th>
            <th>Wed</th>
            <th>Thu</th>
            <th>Fri</th>
            <th>Total</th>
            <th>Lead Approval</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {timesheets.map(ts => (
            <tr key={ts.id}>
              <td>{ts.employee.name}</td>
              <td>{ts.week}</td>
              <td>{ts.mon}</td>
              <td>{ts.tue}</td>
              <td>{ts.wed}</td>
              <td>{ts.thu}</td>
              <td>{ts.fri}</td>
              <td>{ts.total}</td>
              <td>{ts.lead_approval}</td>
              
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Timesheet;
