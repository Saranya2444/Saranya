// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import EmployeeDetail from './components/EmployeeDetail';
import EmployeeTimesheet from './components/EmployeeTimesheet';
import Login from './components/Login';
//import Profile from './components/Profile';
import ManagerDashboard from './components/ManagerDashboard';
import Sidebar from './components/Sidebar';
import './App.css'

import TimeSheetForm from './components/TimeSheetForm';

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    return (
        <Router>
            {!isLoggedIn ? (
                <Routes>
                    
                    
                    //<Route exact path="/" element={<Login onLogin={() => setIsLoggedIn(true)} />} />
                    <Route exact path="/login" element={<Login onLogin={() => setIsLoggedIn(true)} />} />
                </Routes>
            ) : (
                <>
                    <Sidebar />
                    <Routes>
                        <Route exact path="/lead-dashboard" element={<Dashboard />} />
                        <Route exact path="/employee/:emp_id" element={<EmployeeDetail />} />
                        <Route exact path="/timesheet/:emp_id" element={<EmployeeTimesheet />} />
                        
                        <Route exact path="/manager-dashboard" element={<ManagerDashboard />} />
                        <Route exact path="/employee-dashboard" element={<TimeSheetForm/>} />
            
                    </Routes>
               
                
                
               
                </>
            )}
        </Router>
    );
}

export default App;
