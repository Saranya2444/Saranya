from django.apps import AppConfig


class TimeTitansAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'time_titans_app'
