from django.contrib import admin
from .models import MyUser, EmployeeDetail, TimeSheet

admin.site.register(MyUser)
admin.site.register(EmployeeDetail)
admin.site.register(TimeSheet)
