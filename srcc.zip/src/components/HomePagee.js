// src/HomePage.js
import React from 'react';
 

const HomePagee = ({ employeeName }) => {
  return (
    <div className="home-page">
      <h1>WELCOME, {employeeName} <span role="img" aria-label="smile">😊</span></h1>
      <div className="greeting">
        Hello there! How can we assist you today?
      </div>
    </div>
  );
};

export default HomePagee;
