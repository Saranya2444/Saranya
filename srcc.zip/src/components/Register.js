import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './styles.css'; 
const Register = () => {
    const [formData, setFormData] = useState({
        employee_name: '',
        employee_id: '',
        email: '',
        password: '',
        confirmPassword: '',
    });
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
           navigate('/login'); // Redirect to login page after registration
        } catch (error) {
            console.error('Error registering', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="employee_name" placeholder="Employee Name" onChange={handleChange} required />
            <input type="text" name="employee_id" placeholder="Employee ID" onChange={handleChange} required />
            <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
            <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
            <button type="submit">Register</button>
        </form>
    );
};

export default Register;
