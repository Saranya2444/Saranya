import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const LeadDashboard = () => {
  const [employeeList, setEmployeeList] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch employee list for lead dashboard
    axios.get('http://127.0.0.1:8000/api/employee-details/')
      .then(response => {
        setEmployeeList(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the employee list!', error);
      });
  }, []);

  const handleViewDetails = (employeeId) => {
    navigate(`/employees/${employeeId}`);
  };

  return (
    <div>
      <h2>Lead Dashboard</h2>
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Emp ID</th>
            <th>Project</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {employeeList.map(employee => (
            <tr key={employee.emp_id}>
              <td>{employee.employee_name}</td>
              <td>{employee.emp_id}</td>
              <td>{employee.project_name}</td>
              <td>
                <button onClick={() => handleViewDetails(employee.emp_id)}>View Details</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LeadDashboard;
