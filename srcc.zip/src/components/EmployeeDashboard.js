import React from 'react';

const EmployeeDashboard = () => {
  return <div>Employee Dashboard</div>;
};

export default EmployeeDashboard;