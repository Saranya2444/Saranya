import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ViewTimesheet.css';

const ViewTimesheet = () => {
  const [timesheets, setTimesheets] = useState([]);
  const loggedInEmpId = ['60182']; // Replace with actual logic to get the logged-in employee's ID

  useEffect(() => {
    axios.get(`http://127.0.0.1:8000/api/employee-details/?emp_id=${loggedInEmpId}`)
      .then(response => {
        setTimesheets(response.data);
      })
      .catch(error => {
        console.error('Error fetching timesheets:', error);
      });
  }, [loggedInEmpId]);

  return (
    <div className="view-timesheet-container">
      <h2>View Timesheet</h2>
      <table>
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Project Name</th>
            
            <th>Total Hours Worked</th>
          </tr>
        </thead>
        <tbody>
          {timesheets.map((sheet) => (
            <tr key={sheet.id}>
              <td>{sheet.emp_id}</td>
              <td>{sheet.employee_name}</td>
              <td>{sheet.start_time}</td>
              <td>{sheet.end_time}</td>
              <td>{sheet.project_name}</td>
              <td>{sheet.total_hours_worked}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewTimesheet;
