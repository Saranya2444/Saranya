import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import 'chart.js/auto';
import './HomePage.css'; // Ensure you have a CSS file for styling

const HomePage = ({ employeeName, empId, email }) => {
  const [percentage, setPercentage] = useState(80); // Default percentage

  // Dummy data for the bar chart
  const data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
    datasets: [
      {
        label: 'Attendance Percentage',
        data: [65, 59, 80, 81, 56, 55],
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="home-page">
      <h1>Welcome, {employeeName} <span role="img" aria-label="smile">😊</span></h1>
       
      <div className="content-container">
        <div className="chart-container">
          <Bar data={data} options={options} />
        </div>
        <div className="circular-progress-container">
          <div className="circular-progress">
            <div className="circle">
              <div className="mask full" style={{ transform: `rotate(${1.8 * percentage}deg)` }}>
                <div className="fill" style={{ transform: `rotate(${1.8 * percentage}deg)` }}></div>
              </div>
              <div className="mask half">
                <div className="fill" style={{ transform: `rotate(${1.8 * percentage}deg)` }}></div>
              </div>
              <div className="inside-circle">{percentage}%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;