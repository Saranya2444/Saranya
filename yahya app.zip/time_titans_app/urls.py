from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import get_users_by_position
from .views import CalculateSalaryView,CalculateLeaveDaysView
from .views import (
    LeadAssignmentListCreateView, LeadAssignmentDetailView,
    LoginView, RegisterView, EmployeeDetailView, 
    EmployeeDetailByEmpIDView, EmployeeDetailByEmpIDView1,
    UpdateApprovalView, ProjectViewSet
)

# Create a router and register our viewsets with it
router = DefaultRouter()
router.register(r'projects', ProjectViewSet, basename='project')

urlpatterns = [
    path('', include(router.urls)),  # Register the router URLs
    path('api/', include(router.urls)),  # This will expose /api/projects/
    path('login/', LoginView.as_view(), name='login'),
    path('register/', RegisterView.as_view(), name='register'),
    path('employee-details/', EmployeeDetailView.as_view(), name='employee-list'),
    path('employee-details/<emp_id>/', EmployeeDetailByEmpIDView.as_view(), name='employee-detail'),
    path('employee-details1/<emp_id>/', EmployeeDetailByEmpIDView1.as_view(), name='employee-detail1'),
    path('employee-details/<str:emp_id>/update_approval/', UpdateApprovalView.as_view(), name='update-approval'),
    path('api/users/', get_users_by_position, name='get_users_by_position'),

    path('lead-assignments/', LeadAssignmentListCreateView.as_view(), name='lead-assignment-list-create'),
    path('lead-assignments/<int:pk>/', LeadAssignmentDetailView.as_view(), name='lead-assignment-detail'),
    path('employee-details/<str:emp_id>/calculate_salary/', CalculateSalaryView.as_view(), name='calculate-salary'),
    path('employee-details/<str:emp_id>/calculate_leave_days/', CalculateLeaveDaysView.as_view(), name='calculate-leave-days'),
]

