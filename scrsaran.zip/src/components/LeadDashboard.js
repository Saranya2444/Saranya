// src/components/LeadDashboard.js
import React from 'react';

const LeadDashboard = () => {
  return (
    <div>
      <h1>Lead Dashboard</h1>
      <p>Welcome to the Lead Dashboard!</p>
    </div>
  );
};

export default LeadDashboard;
