// src/components/EmployeeDashboard.js
import React from 'react';

const EmployeeDashboard = () => {
  return (
    <div>
      <h1>Employee Dashboard</h1>
      <p>Welcome to the Employee Dashboard!</p>
    </div>
  );
};

export default EmployeeDashboard;
