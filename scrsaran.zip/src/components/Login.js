// src/components/Login.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    userid: '',
    password: '',
  });

  const { userid, password } = formData;
  const navigate = useNavigate();

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    const user = { userid, password };

    try {
      const res = await axios.post('http://localhost:8000/api/login/', user);
      console.log(res.data);
      // Redirect based on person status
      if (res.data.redirect_url) {
        navigate(res.data.redirect_url);
      } else {
        console.error('No redirect URL found in the response');
      }
    } catch (err) {
      console.error(err.response.data);
    }
  };

  return (
    <form onSubmit={onSubmit}>
      <input type="text" name="userid" value={userid} onChange={onChange} placeholder="User ID" required />
      <input type="password" name="password" value={password} onChange={onChange} placeholder="Password" required />
      <button type="submit">Login</button>
    </form>
  );
};

export default Login;
