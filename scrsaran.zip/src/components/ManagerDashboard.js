// src/components/ManagerDashboard.js
import React from 'react';

const ManagerDashboard = () => {
  return (
    <div>
      <h1>Manager Dashboard</h1>
      <p>Welcome to the Manager Dashboard!</p>
    </div>
  );
};

export default ManagerDashboard;
