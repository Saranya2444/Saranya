// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './Dashboard';
import EmployeeDetail from './EmployeeDetail';
import EmployeeTimesheet from './EmployeeTimesheet';
import Login from './Login';

import Login from './components/Login';

import EmployeeDashboard from './components/EmployeeDashboard';
import LeadDashboard from './components/LeadDashboard';
import ManagerDashboard from './components/ManagerDashboard';

function App() {
    return (
        <Router>
            <div>
                <Routes>
                   
                    <Route exact path="/login" element={<Login />} />
                    
                </Routes>
            </div>
        </Router>
    );
}

export default App;
