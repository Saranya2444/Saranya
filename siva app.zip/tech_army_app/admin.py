from django.contrib import admin
from .models import MyUser, EmployeeDetail, TimeSheet, ManagerSheet, TeamleaderSheet

@admin.register(MyUser)
class MyUserAdmin(admin.ModelAdmin):
    list_display = ('email', 'userid', 'name', 'phone_number', 'personstatus', 'is_active', 'is_admin')
    search_fields = ('email', 'userid', 'name')
    list_filter = ('personstatus', 'is_active', 'is_admin')

@admin.register(ManagerSheet)
class ManagerSheetAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'dead_line')
    search_fields = ('project_name',)
    list_filter = ('dead_line',)

@admin.register(TeamleaderSheet)
class TeamleaderSheetAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'module_name', 'userid')
    search_fields = ('module_name', 'userid__name')
    list_filter = ('project_name', 'userid')

@admin.register(EmployeeDetail)
class EmployeeDetailAdmin(admin.ModelAdmin):
    list_display = ('employee', 'team_name', 'date', 'project_name', 'module_name', 'start_time', 'end_time', 'total_hours', 'lead_approval')
    search_fields = ('employee__name', 'team_name', 'project_name__project_name', 'module_name__module_name')
    list_filter = ('date', 'lead_approval', 'project_name', 'module_name')

@admin.register(TimeSheet)
class TimeSheetAdmin(admin.ModelAdmin):
    list_display = ('employee', 'week', 'mon', 'tue', 'wed', 'thu', 'fri', 'total', 'lead_approval')
    search_fields = ('employee__name', 'week')
    list_filter = ('week', 'lead_approval', 'employee')
