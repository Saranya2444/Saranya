from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from .models import MyUser, EmployeeDetail, TimeSheet, ManagerSheet, TeamleaderSheet
from .serializers import *

class RegisterView(CreateAPIView):
    queryset = MyUser.objects.all()
    serializer_class = RegisterSerializer

class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        userid = serializer.validated_data['userid']
        password = serializer.validated_data['password']

        user = MyUser.objects.filter(userid=userid).first()

        if user and user.check_password(password):  # Use Django's built-in method to check the hashed password
            personstatus = getattr(user, 'personstatus', None)

            response_data = {
                'userid': userid,
                'personstatus': personstatus,
                'redirect_url': self.get_redirect_url(personstatus)
            }
            return Response(response_data, status=status.HTTP_200_OK)
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

    def get_redirect_url(self, personstatus):
        redirect_urls = {
            'Employee': '/employee-dashboard/',
            'Lead': '/lead-dashboard/',
            'Manager': '/manager-dashboard/',
        }
        return redirect_urls.get(personstatus, '/')

class ChangePasswordView(APIView):
    def post(self, request):
        userid = request.data.get('userid')
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        user = MyUser.objects.filter(userid=userid).first()
        if user and user.check_password(old_password):
            user.set_password(new_password)
            user.save()
            return Response({'status': 'password changed'}, status=status.HTTP_200_OK)
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

class EmployeeDetailView(APIView):
    def get(self, request, userid=None):
        if userid:
            try:
                employee = MyUser.objects.get(userid=userid)
                employee_details = EmployeeDetail.objects.filter(employee=employee).first()
                if employee_details:
                    serializer = EmployeeDetailSerializer(employee_details)
                    return Response(serializer.data, status=status.HTTP_200_OK)
                return Response({'error': 'Employee detail not found'}, status=status.HTTP_404_NOT_FOUND)
            except MyUser.DoesNotExist:
                return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        else:
            employees = MyUser.objects.all()
            serializer = MyUserSerializer(employees, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = EmployeeDetailSerializer(data=request.data)
        if serializer.is_valid():
            employee_id = request.data.get('employee')
            try:
                employee = MyUser.objects.get(userid=employee_id)
                serializer.save(employee=employee)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            except MyUser.DoesNotExist:
                return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class TimeSheetViewSet(viewsets.ModelViewSet):
    queryset = TimeSheet.objects.all()
    serializer_class = TimeSheetSerializer

    # @action(detail=False, methods=['post'])
    # def add(self, request):
    #     print(request.data)
        
    #     serializer = self.get_serializer(data=request.data)
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data, status=status.HTTP_201_CREATED)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    # @action(detail=False, methods=['post'])
    # def add(self, request):
    #     print("Add action called with data:", request.data)
    #     data = request.data
    #     employee = employee = MyUser.objects.get(userid=data['id'])
    #     data['employee'] = employee
    #     print(data)
    #     serializer = self.get_serializer(data=request.data)
    #     print(serializer)
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data, status=status.HTTP_201_CREATED)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    @action(detail=False, methods=['post'])
    def add(self, request):
        data = request.data
        employee_id = data.get('id')
        
        try:
            employee = MyUser.objects.get(userid=employee_id)
        except MyUser.DoesNotExist:
            return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        
        # Modify the data to include the employee ID directly
        data['employee'] = employee.id
        serializer = self.get_serializer(data=data)
        
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Approved'
        timesheet.save()
        return Response({'status': 'timesheet approved'})

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Rejected'
        timesheet.save()
        return Response({'status': 'timesheet rejected'})

class ManagerSheetViewSet(viewsets.ModelViewSet):
    queryset = ManagerSheet.objects.all()
    serializer_class = ManagerSheetSerializer

class TeamleaderSheetViewSet(viewsets.ModelViewSet):
    queryset = TeamleaderSheet.objects.all()
    serializer_class = TeamleaderSheetSerializer
