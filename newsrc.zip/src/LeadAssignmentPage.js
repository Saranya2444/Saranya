import React, { useState, useEffect } from 'react';
import axios from 'axios';
import EmployeeLis from './EmployeeLis'; // Corrected Component Name
import LeadAssignmentForm from './LeadAssignmentForm';

const LeadAssignmentPage = () => {
    const [projects, setProjects] = useState([]);
    const [selectedProject, setSelectedProject] = useState(null);
    const [assignedEmployees, setAssignedEmployees] = useState([]);
    const [showEmployeeList, setShowEmployeeList] = useState(false);

    useEffect(() => {
        axios.get('http://127.0.0.1:8000/api/projects/')
            .then(response => setProjects(response.data))
            .catch(error => console.error('Error fetching projects:', error));
    }, []);

    const handleProjectClick = (project) => {
        setSelectedProject(project);
        setShowEmployeeList(true);
        // Fetch already assigned employees for this project
        axios.get(`http://127.0.0.1:8000/api/lead-assignments/${project.id}/`)
            .then(response => setAssignedEmployees(response.data.assigned_to_employees))
            .catch(error => console.error('Error fetching lead assignment:', error));
    };

    const handleEmployeeAdd = (employee) => {
        if (!assignedEmployees.some(emp => emp.id === employee.id)) {
            setAssignedEmployees([...assignedEmployees, employee]);
        }
    };

    const handleOkClick = () => {
        axios.post(`http://127.0.0.1:8000/api/lead-assignments/${selectedProject.id}/`, {
            assigned_to_employees: assignedEmployees.map(emp => emp.id),
        })
        .then(response => {
            console.log('Assignment saved:', response.data);
            setShowEmployeeList(false);
        })
        .catch(error => console.error('Error saving assignment:', error));
    };

    return (
        <div>
            <h2>Lead Assignment</h2>
             
                <LeadAssignmentForm
                    project={selectedProject}
                    assignedEmployees={assignedEmployees}
                    onEmployeeAdd={handleEmployeeAdd}
                    onOkClick={handleOkClick}
                />
            
        </div>
    );
};

export default LeadAssignmentPage;
