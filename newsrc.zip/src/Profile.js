import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Profile = () => {
    const [profile, setProfile] = useState({});

    useEffect(() => {
        const fetchProfile = async () => {
            const empId = localStorage.getItem('empId');
            const response = await axios.get(`http://localhost:8000/api/profile/${empId}`);
            setProfile(response.data);
        };

        fetchProfile();
    }, []);

    return (
        <div>
            <h2>Profile</h2>
            <p>Name: {profile.employee_name}</p>
            <p>Employee ID: {profile.emp_id}</p>
            <p>Email: {profile.email}</p>
            {/* Add more fields as necessary */}
        </div>
    );
};

export default Profile;
