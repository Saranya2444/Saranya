import java.io.*;
class print{

    public static void main(String a[])throws exception
    {
        DataInputStream d=new DataInputStream(System.in);
        String s=d.readLine();
        Sytem.out.println(s);
    }
}