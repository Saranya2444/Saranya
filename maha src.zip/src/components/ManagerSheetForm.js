import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ManagerSheetForm = () => {
    const [projectName, setProjectName] = useState('');
    const [deadLine, setDeadLine] = useState('');
    const [teamLeaders, setTeamLeaders] = useState([]);
    const [selectedTeamLeader, setSelectedTeamLeader] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    useEffect(() => {
        // Fetch team leaders
        const fetchTeamLeaders = async () => {
            try {
                const response = await axios.get('http://127.0.0.1:8000/api/leads/');
                setTeamLeaders(response.data);
            } catch (err) {
                console.error('Error fetching team leaders:', err);
                setError('Failed to fetch team leaders.');
            }
        };
        fetchTeamLeaders();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://127.0.0.1:8000/api/manager/', {
                project_name: projectName,
                dead_line: deadLine,
                team_leader: selectedTeamLeader,
            });
            console.log('Manager sheet created:', response.data);
            setSuccess('Manager sheet created successfully.');
            setError('');  // Clear any previous errors
            // Optionally clear the form or redirect the user
            setProjectName('');
            setDeadLine('');
            setSelectedTeamLeader('');
        } catch (err) {
            console.error('Error creating manager sheet:', err);
            setError('Failed to create manager sheet.');
            setSuccess('');  // Clear any previous success messages
        }
    };

    return (
        <div>
            <h1>Create Manager Sheet</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {success && <p style={{ color: 'green' }}>{success}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="project_name">Project Name:</label>
                    <input
                        type="text"
                        id="project_name"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="dead_line">Deadline:</label>
                    <input
                        type="date"
                        id="dead_line"
                        value={deadLine}
                        onChange={(e) => setDeadLine(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="team_leader">Team Leader:</label>
                    <select
                        id="team_leader"
                        value={selectedTeamLeader}
                        onChange={(e) => setSelectedTeamLeader(e.target.value)}
                        required
                    >
                        <option value="">Select Team Leader</option>
                        {teamLeaders.map((leader) => (
                            <option key={leader.userid} value={leader.userid}>
                                {leader.userid} {/* Adjust if `name` is available */}
                            </option>
                        ))}
                    </select>
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default ManagerSheetForm;
