// src/components/TimesheetTable.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TimesheetTable.css';

const TimesheetTable = () => {
  const [timesheets, setTimesheets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTimesheets = async () => {
      try {
        const token = localStorage.getItem('token'); // Adjust according to how you store the token
        const response = await axios.get('http://127.0.0.1:8000/api/timesheet/', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        console.log(response.data); // Debugging line
        setTimesheets(response.data);
      } catch (error) {
        setError('Error fetching timesheets');
        console.error('Error fetching timesheets:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTimesheets();
  }, []);

  if (loading) return <p className="loading">Loading...</p>;
  if (error) return <p className="error">{error}</p>;

  return (
    <div className="table-container">
      <table>
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Project Name</th>
            <th>Module Name</th>
            <th>Week</th>
            <th>Monday</th>
            <th>Tuesday</th>
            <th>Wednesday</th>
            <th>Thursday</th>
            <th>Friday</th>
            <th>Total Hours</th>
            <th>Lead Approval</th>
            <th>Manager Approval</th>
          </tr>
        </thead>
        <tbody>
          {timesheets.map((timesheet) => (
            <tr key={timesheet.id}>
              <td>{timesheet.id}</td>
              <td>{timesheet.project_name}</td>
              <td>{timesheet.module_name}</td>
              <td>{timesheet.week}</td>
              <td>{timesheet.mon}</td>
              <td>{timesheet.tue}</td>
              <td>{timesheet.wed}</td>
              <td>{timesheet.thu}</td>
              <td>{timesheet.fri}</td>
              <td>{timesheet.total}</td>
              <td>{timesheet.lead_approval }</td>
              <td>{timesheet.manager_approval}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TimesheetTable;
