# myapp/urls.py
from django.urls import path
from .views import LoginView, RegisterView, EmployeeDetailView, EmployeeDetailByEmpIDView, EmployeeListView,EmployeeDetailByEmpIDView1,UpdateApprovalView

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),
    path('register/', RegisterView.as_view(), name='register'),
    path('employee-details/', EmployeeDetailView.as_view(), name='employee-list'),
    path('employee-details/<emp_id>/', EmployeeDetailByEmpIDView.as_view(), name='employee-detail'),
    path('employee-details1/<emp_id>/', EmployeeDetailByEmpIDView1.as_view(), name='employee-detail'),
    path('employee-details/<emp_id>/update_approval/', UpdateApprovalView.as_view(), name='update-approval'),  # Updated this line

]