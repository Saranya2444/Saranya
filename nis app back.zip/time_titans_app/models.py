from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.utils import timezone

class UserManager(BaseUserManager):
    def create_user(self, username, email, emp_id, position, joining_date, password=None):
        if not email:
            raise ValueError('Users must have an email address')
        user = self.model(
            username=username,
            email=self.normalize_email(email),
            emp_id=emp_id,
            position=position,
            joining_date=joining_date
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, emp_id, position, joining_date, password=None):
        user = self.create_user(
            username=username,
            email=email,
            emp_id=emp_id,
            position=position,
            joining_date=joining_date,
            password=password
        )
        user.is_admin = True
        user.save(using=self._db)
        return user

class User(AbstractBaseUser):
    POSITION_CHOICES = [
        ('employee', 'Employee'),
        ('lead', 'Lead'),
        ('manager', 'Manager'),
    ]

    username = models.CharField(max_length=30, unique=True)
    email = models.EmailField(max_length=255, unique=True)
    emp_id = models.CharField(max_length=10, unique=True, primary_key=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    Time_stamp = models.DateTimeField(default=timezone.now)
    position = models.CharField(max_length=10, choices=POSITION_CHOICES, default='employee')
    joining_date = models.DateField()

    objects = UserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email', 'emp_id', 'position', 'joining_date']

    def __str__(self):
        return self.emp_id

    def has_perm(self, perm, obj=None):
        return self.is_admin

    def has_module_perms(self, app_label):
        return self.is_admin

class Project(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    emp_id = models.ForeignKey(User, on_delete=models.CASCADE)
    project_name = models.CharField(max_length=100)
    project_module = models.CharField(max_length=100)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.project_name} ({self.emp_id.emp_id})"

class EmployeeDetail(models.Model):
    emp_id = models.ForeignKey(User, on_delete=models.CASCADE)
    employee_name = models.CharField(max_length=100)
    start_time = models.TimeField()
    end_time = models.TimeField()
    project_name = models.CharField(max_length=100, editable=False)
    comments = models.TextField()
    date = models.DateField()
    total_hours_worked = models.DecimalField(max_digits=5, decimal_places=2)
    lead_approval = models.CharField(max_length=20, choices=[('approved', 'Approved'), ('rejected', 'Rejected'),
                                                             ('pending', 'Pending')], default='pending')
    manager_approval = models.CharField(max_length=20, choices=[('approved', 'Approved'), ('rejected', 'Rejected'),
                                                                ('pending', 'Pending')], default='pending')

    def __str__(self):
        return self.employee_name

    def save(self, *args, **kwargs):
        # Fetch the project name from Project model
        project = Project.objects.filter(emp_id=self.emp_id).first()
        if project:
            self.project_name = project.project_name
        super().save(*args, **kwargs)