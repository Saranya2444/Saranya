import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import 'chart.js/auto';
import './HomePage.css'; // Ensure you have a CSS file for styling

const HomePage = ({ employeeName, empid, email }) => {
  const [daysInfo, setDaysInfo] = useState({
    total_days: 0,
    working_days: 0,
    leave_days: 0,
  });
  const [percentage, setPercentage] = useState(0);

  useEffect(() => {
    axios.get(`http://127.0.0.1:8000/api/user-details/${empid}/`)
      .then(response => {
        setDaysInfo(response.data);
        const workDays = response.data.working_days;
        const totalDays = response.data.total_days;
        const attendancePercentage = (workDays / totalDays) * 100;
        setPercentage(attendancePercentage);
      })
      .catch(error => {
        console.error('Error fetching user details:', error);
      });
  }, [empid]);

  const data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
    datasets: [
      {
        label: 'Attendance Percentage',
        data: [65, 59, 80, 81, 56, 55],
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="home-page">
      <h1>Welcome, {employeeName} <span role="img" aria-label="smile">😊</span></h1>
      <p>ID: {empid}</p>
      <p>Email: {email}</p>
      <p>Total Days: {daysInfo.total_days}</p>
      <p>Working Days: {daysInfo.working_days}</p>
      <p>Leave Days: {daysInfo.leave_days}</p>
      <div className="content-container">
        <div className="chart-container">
          <Bar data={data} options={options} />
        </div>
        <div className="circular-progress-container">
          <div className="circular-progress">
            <div className="circle">
              <div className="mask full" style={{ transform: `rotate(${1.8 * percentage}deg)` }}>
                <div className="fill" style={{ transform: `rotate(${1.8 * percentage}deg)` }}></div>
              </div>
              <div className="mask half">
                <div className="fill" style={{ transform: `rotate(${1.8 * percentage}deg)` }}></div>
              </div>
              <div className="inside-circle">{percentage.toFixed(2)}%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
