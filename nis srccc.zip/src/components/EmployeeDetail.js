import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const EmployeeDetail = ({ onStatusChange, userRole }) => {
  const { id: empId } = useParams(); // Get employeeId from URL params
  const [employeeDetail, setEmployeeDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const storedPosition = localStorage.getItem('position');
    console.log('fetched status:', storedPosition);
    if (empId) { // Check if id is provided
      // Fetch the employee details from the API
      console.log(empId)
      axios.get(`http://127.0.0.1:8000/api/employee-details/${empId}/`)
        .then(response => {
          console.log('Employee data:', response.data);
          setEmployeeDetail(response.data);
          setLoading(false);
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
          setError('There was an error fetching the employee details.');
          setLoading(false);
        });
    }
  }, [empId]);

  const handleApprovalChange = (empId, action, approvalType) => {
    // Update approval status in the backend
    const endpoint = `http://127.0.0.1:8000/api/employee-details/${empId}/update_approval/`;

    axios.post(endpoint, { action, approvalType, userRole })
      .then(response => {
        console.log('Approval updated:', response.data);
        setEmployeeDetail(prevState => ({
          ...prevState,
          [approvalType]: action === 'approve' ? 'approve' : 'reject'
        }));
        onStatusChange(empId, action === 'approve' ? 'Approve' : 'Reject'); // Notify parent component of the status change
      })
      .catch(error => {
        console.error('There was an error updating the approval status!', error);
        setError('There was an error updating the approval status.');
      });
  };

  if (loading) {
    return <div>Loading...{empId} pass</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div>
      <h2>Employee Details</h2>
      {userRole} hello
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Emp ID</th>
            <th>Date</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Project Name</th>
            <th>Total Worked Hours</th>
            {userRole === 'lead' && <th>Lead Approval</th>}
            {userRole === 'manager' && (
              <>
                <th>Lead Approval</th>
                <th>Manager Approval</th>
              </>
            )}
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{employeeDetail.employee_name}</td>
            <td>{employeeDetail.emp_id}</td>
            <td>{employeeDetail.date}</td>
            <td>{employeeDetail.start_time}</td>
            <td>{employeeDetail.end_time}</td>
            <td>{employeeDetail.project_name}</td>
            <td>{employeeDetail.total_hours_worked}</td>
            {userRole === 'lead' && (
              <td>
                {employeeDetail.lead_approval === 'pending' ? (
                  <>
                    <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'approve', 'lead_approval')}>Approve</button>
                    <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'reject', 'lead_approval')}>Reject</button>
                  </>
                ) : (
                  employeeDetail.lead_approval
                )}
              </td>
            )}
            {userRole === 'manager' && (
              <>
                <td>
                  {employeeDetail.lead_approval === 'pending' ? (
                    <>
                      <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'approve', 'lead_approval')}>Approve</button>
                      <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'reject', 'lead_approval')}>Reject</button>
                    </>
                  ) : (
                    employeeDetail.lead_approval
                  )}
                </td>
                <td>
                  {employeeDetail.manager_approval === 'pending' ? (
                    <>
                      <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'approve', 'manager_approval')}>Approve</button>
                      <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'reject', 'manager_approval')}>Reject</button>
                    </>
                  ) : (
                    employeeDetail.manager_approval
                  )}
                </td>
              </>
            )}
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeDetail;
