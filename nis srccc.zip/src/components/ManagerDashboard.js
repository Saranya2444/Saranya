import React from 'react';

const ManagerDashboard = () => {
  return <div>Manager Dashboard</div>;
};

export default ManagerDashboard;