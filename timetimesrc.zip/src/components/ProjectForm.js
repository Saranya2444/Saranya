import React, { useState } from 'react';
import axios from 'axios';

const ProjectForm = () => {
  const [projectName, setProjectName] = useState('');
  const [projectModule, setProjectModule] = useState('');
  const [status, setStatus] = useState('pending');

  const handleSubmit = (e) => {
    e.preventDefault();
    const projectData = {
      project_name: projectName,
      project_module: projectModule,
      status: status,
    };

    axios.post('http://127.0.0.1:8000/api/projects/', projectData)
      .then(response => {
        console.log('Project created successfully:', response.data);
      })
      .catch(error => {
        console.error('There was an error creating the project!', error);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Project Name:</label>
        <input
          type="text"
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
        />
      </div>
      <div>
        <label>Project Module:</label>
        <input
          type="text"
          value={projectModule}
          onChange={(e) => setProjectModule(e.target.value)}
        />
      </div>
      <div>
        <label>Status:</label>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>
      <button type="submit">Save Project</button>
    </form>
  );
};

export default ProjectForm;
