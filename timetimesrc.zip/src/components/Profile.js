import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Profile.css';

const Profile = () => {
  const [profile, setProfile] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const loggedInEmpId = localStorage.getItem('empId'); // Fetch the logged-in emp_id from localStorage or context

  useEffect(() => {
    // Fetch employee details based on logged-in emp_id
    axios.get(`http://127.0.0.1:8000/api/employee-details/${loggedInEmpId}/`)
      .then(response => {
        setProfile(response.data);
        setLoading(false);
      })
      .catch(error => {
        setError('Error fetching profile');
        setLoading(false);
      });
  }, [loggedInEmpId]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="profile-container">
      <h2>Profile</h2>
      <p><strong>Employee ID:</strong> {profile.emp_id}</p>
      <p><strong>Employee Name:</strong> {profile.employee_name}</p>
    </div>
  );
};

export default Profile;
