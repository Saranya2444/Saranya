import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Sidebars from './components/Sidebars';
import CalendarTable from './components/CalendarTable';
import HomePage from './components/HomePage';
import TeamTable from './components/TeamTable';
import EmployeeList from './components/EmployeeList';
import EmployeeDetail from './components/EmployeeDetail';
import LoginForm from './components/LoginForm';
import './App.css';
import ProjectForm from './components/ProjectForm';
import EmployeeDashboard from './components/EmployeeDashboard';
import ManagerDashboard from './components/ManagerDashboard';
import Dashboard from './components/Dashboard';
import UpdateTimesheet from './components/UpdateTimesheet';
import ViewTimesheet from './components/ViewTimesheet';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [empid, setEmpid] = useState(null);
  const [loggedInEmpId, setLoggedInEmpId] = useState(null);
  const [email, setEmail] = useState('');
  const [employeeName, setEmployeeName] = useState('');
  const [userRole, setUserRole] = useState('employee');
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = (empid) => {
    setEmpid(empid);
    setIsLoggedIn(true);
    axios.get(`http://127.0.0.1:8000/api/employee-details1/${empid}/`)
      .then(response => {
        setEmployeeName(response.data.employee_name);
        setEmail(response.data.email);
        setUserRole(response.data.position);
        setLoggedInEmpId(response.data.emp_id);
      })
      .catch(error => {
        console.error('There was an error fetching the employee details!', error);
      });
  };

  useEffect(() => {
    if (empid) {
      axios.get(`http://127.0.0.1:8000/api/employee-details1/${empid}/`)
        .then(response => {
          setEmployeeName(response.data.employee_name);
          setEmail(response.data.email);
          setUserRole(response.data.position);
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
        });
    }
  }, [empid]);

  const handleCalendarClick = () => {
    navigate('/calendar');
  };

  const handleStatusChange = (empId, action) => {
    console.log(`Status for employee ${empId} changed to ${action}`);
    // Implement additional logic for handling status change if needed
  };

  const handleSelectEmployee = (employeeId) => {
    navigate(`/employees/${employeeId}`);
  };

  if (!isLoggedIn) {
    return <LoginForm onLogin={handleLogin} />;
  }

  const showSidebar = !location.pathname.startsWith('/dashboard');

  return (
    <div className="app">
      <Navbar />
      <div className="main-content-container">
        {showSidebar ? (
          <Sidebar onCalendarClick={handleCalendarClick} />
        ) : (
          <Sidebars onCalendarClick={handleCalendarClick} />
        )}
        <div className="main-content">
          <Routes>
            <Route path="/login" element={<LoginForm onLogin={handleLogin} />} />
            <Route path="/dashboard/*" element={<Dashboard empid={empid} employeeName={employeeName} email={email}/>} />
            <Route path="/employee-dashboard" element={<EmployeeDashboard />} />
            <Route path="/manager-dashboard" element={<ManagerDashboard />} />
            <Route path="/home" element={<HomePage employeeName={employeeName} empid={empid} email={email} />} />
            <Route path="/calendar" element={<CalendarTable empid={empid} employeeName={employeeName} />} />
            <Route path="/employees" element={<EmployeeList onSelectEmployee={handleSelectEmployee} />} />
            <Route path="/employees/:id" element={<EmployeeDetail onStatusChange={handleStatusChange} userRole={userRole} />} />
            <Route path="/teamtable" element={<TeamTable />} />
            <Route path="/profile" element={<HomePage empid={empid} employeeName={employeeName} email={email}/>} />
            <Route path="/update-timesheet" element={<UpdateTimesheet />} />
            <Route path="/view-timesheet" element={<ViewTimesheet empid={empid} />} />
            <Route path="/projects" element={<ProjectForm />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default App;