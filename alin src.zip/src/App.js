// src/App.js
import React, { useState,useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import Dashboard1 from './components/Dashboard1';
import EmployeeDetail from './components/EmployeeDetail';
import EmployeeTimesheet from './components/EmployeeTimesheet';
import Login from './components/Login';
import ManagerDashboard from './components/ManagerDashboard';
import ManagerDashboard1 from './components/ManagerDashboard1';
import Sidebar from './components/Sidebar';
import Sidebar1 from './components/Sidebar1';
import Sidebar2 from './components/Sidebar2';
//import TimesheetForm from './components/TimesheetForm';
//import TimesheetTable from './components/TimesheetTable';
import './App.css'
import TimesheetForm from './components/TimesheetForm';
import TimesheetTable from './components/TimesheetTable';
import Leavedays from './components/Leavedays';
import ManagerSheetForm from './components/ManagerSheetForm';
import TeamleaderSheetForm from './components/TeamleaderSheetForm';
function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [personstatus, setPersonstatus] = useState('');
    useEffect(() => {
        // Fetch employee details
        
        const storedPersonstatus = localStorage.getItem('personstatus');
       
        if (storedPersonstatus) {
            setPersonstatus(storedPersonstatus);
        }
        
            },[]);
            const renderSidebar = () => { 
                switch (personstatus) {
                     case 'Employee':
                         return <Sidebar2 />; 
                     case 'Manager':
                         return <Sidebar1 />; 
                     case 'Lead':
                         return <Sidebar />; 
                     default: return null;
                     }
                     };
    
    return (
        <Router>
           
                <Routes>
                   <Route exact path="/" element={<Login onLogin={(handleLogin) => setIsLoggedIn(true)} />} />
                   <Route exact path="/login" element={<Login onLogin={(handleLogin) => setIsLoggedIn(true)} />} />
                </Routes>
           
                <>
                <>
                {renderSidebar()}
                    
                    <Routes>
                    
                    <Route exact path="/" element={<Dashboard />} />
                        <Route exact path="/lead-dashboard" element={<Dashboard />} />
                        <Route exact path="/employeetimesheet" element={<Dashboard1 />} />
                        
                        <Route exact path="/employee/:emp_id" element={<EmployeeDetail />} />
                        <Route exact path="/timesheet/:emp_id" element={<EmployeeTimesheet />} />
                         
                        <Route exact path="/manager-dashboard" element={<ManagerDashboard />} />
                        <Route exact path="/manager" element={<ManagerDashboard1 />} />
                        <Route exact path="/employee-dashboard" element={<TimesheetForm />} />
                        <Route exact path="/view" element={<TimesheetTable />} />
                        <Route exact path="/leave" element={<Leavedays />} />
                        <Route exact path="/proj" element={<ManagerSheetForm />} />
                        <Route exact path="/mod" element={<TeamleaderSheetForm />} />
                    </Routes>
                    
                  
                
               
                </>
                </>
                
            
        </Router>
    );
}
export default App;