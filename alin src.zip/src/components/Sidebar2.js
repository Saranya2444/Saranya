import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClock, faHome, faFileAlt, faChartBar } from '@fortawesome/free-solid-svg-icons';
import './Sidebar.css';
import { Link } from 'react-router-dom';

const Sidebar2 = () => {
  return (
    <div className="sidebar">
      <div className="sidebar-title">
        <FontAwesomeIcon icon={faClock} />
        <span>Dashboard</span>
      </div>
      <div className="sidebar-search">
        <input type="text" placeholder="Search..." />
      </div>
      <div className="sidebar-menu">
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faHome} />
          <span><Link to="employee-dashboard" className="sidebar-link">Add Timesheet</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faFileAlt} />
          <span><Link to="view" className="sidebar-link">View Timesheet</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faChartBar} />
          <span><Link to="/leave" className="sidebar-link">attendance</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faChartBar} />
          <span><Link to="/login" className="sidebar-link">Logout</Link></span>
        </div>
      </div>
    </div>
  );
};

export default Sidebar2;
